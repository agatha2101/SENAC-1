// AULA 01 — DESENVOLVIMENTO DE SOFTWARE APOIADO POR IA
// Este arquivo começa incompleto de propósito.
// A dupla vai usar IA para completar cada TODO de forma controlada.

const form = document.querySelector("#formChamado");
const titulo = document.querySelector("#titulo");
const categoria = document.querySelector("#categoria");
const prioridade = document.querySelector("#prioridade");
const descricao = document.querySelector("#descricao");
const mensagemErro = document.querySelector("#mensagemErro");

const listaChamados = document.querySelector("#listaChamados");
const filtroStatus = document.querySelector("#filtroStatus");
const totalChamados = document.querySelector("#totalChamados");
const totalAbertos = document.querySelector("#totalAbertos");

// Começamos com uma lista vazia.
// TODO 5: depois esta lista deverá ser carregada do localStorage.
let chamados = [];

// TODO 1
// Crie a função criarChamado().
// Ela deve devolver um objeto com:
// id, titulo, categoria, prioridade, descricao e status.
// O status inicial deve ser "Aberto".

// TODO 2
// Crie a função renderizarChamados().
// Ela deve:
// 1. considerar o valor escolhido em filtroStatus;
// 2. exibir "Nenhum chamado cadastrado." quando não houver itens;
// 3. montar um card para cada chamado;
// 4. exibir título, categoria, prioridade, descrição e status;
// 5. criar um botão "Avançar status" em cada card.

// TODO 3
// Crie a função avancarStatus(id).
// Fluxo obrigatório:
// Aberto -> Em andamento -> Concluído.
// Um chamado concluído continua como Concluído.

// TODO 4
// No submit do formulário:
// 1. impedir o recarregamento da página;
// 2. validar título e descrição;
// 3. mostrar a mensagem "Preencha título e descrição." se algum estiver vazio;
// 4. criar o chamado;
// 5. adicionar na lista chamados;
// 6. limpar o formulário;
// 7. renderizar novamente.

// TODO 5
// Persistência:
// crie salvarChamados() usando localStorage;
// carregue os dados ao abrir a página;
// salve sempre que cadastrar ou mudar o status.

// O filtro deve redesenhar a lista quando mudar.
filtroStatus.addEventListener("change", () => {
  // TODO 2: chamar renderizarChamados()
});

// TODO FINAL
// Atualize os indicadores:
// totalChamados = quantidade total;
// totalAbertos = quantidade de chamados com status "Aberto".
