IAmigo — projeto com arquivos separados

Estrutura:
- index.html: estrutura da interface
- css/style.css: estilos, paleta Liquid Glass e animação do fundo
- js/script.js: funcionalidades e interações

Para testar, mantenha as pastas css e js ao lado de index.html e abra index.html no navegador.
