from fastapi import FastAPI

app = FastAPI(
    title="TPaC API",
    description="API criada na Aula 05",
    version="1.0.0"
)


@app.get("/")
def inicio():
    return {
        "sistema": "TPaC",
        "api": "funcionando"
    }