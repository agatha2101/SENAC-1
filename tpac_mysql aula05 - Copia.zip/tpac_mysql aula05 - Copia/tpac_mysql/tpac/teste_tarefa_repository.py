﻿from repositories.tarefa_repository import TarefaRepository

repo = TarefaRepository()
tarefas = repo.listar()

print(
    "TAREFAS:",
    [
        {
            "id": tarefa.id,
            "titulo": tarefa.titulo,
            "tipo": tarefa.tipo
        }
        for tarefa in tarefas
    ]
)
