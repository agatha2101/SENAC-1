﻿from ui.utils import exibir_cabecalho, exibir_barra_status, exibir_progresso
from data.data_manager import carregar_dados, salvar_dados
import core.tarefas as core_tarefas
from controllers.tarefa_controller import TarefaController
import core.ia_service as ia_service

def criar_usuario_menu(dados: dict):
    exibir_cabecalho("BEM-VINDO(A)")
    nome = input("Como vocÃª gostaria de ser chamado(a)? ").strip()
    if not nome:
        input("\nNÃ£o consegui identificar seu nome. Tente novamente. (ENTER)")
        return

    if nome in dados:
        input(f"\nJÃ¡ encontrei um cadastro com o nome '{nome}'. Tente novamente para seguirmos! (ENTER)")
        return

    print("\nMe conta uma coisa:")
    print("Quando vocÃª precisa fazer algo, o que funciona melhor para vocÃª?")
    print("1. InstruÃ§Ãµes curtas e sem enrolaÃ§Ã£o")
    print("2. Um guia mais detalhado, explicando cada etapa")
    pref = input("OpÃ§Ã£o: ").strip()
    estilo = "direto" if pref == "1" else "detalhado"

    dados[nome] = {
        "preferencias": {"estilo_instrucao": estilo},
        "tarefas_diarias": [],
        "tarefas_educacionais": []
    }
    salvar_dados(dados)
    input(f"\nTudo certo, [{nome}]! Seu perfil foi criado. Pressione Enter para continuar.")

def gerenciar_tarefas_menu(dados: dict, usuario: str, chave: str, titulo: str):
    tarefa_controller = TarefaController()
    while True:
        exibir_cabecalho(titulo)
        tarefas = dados[usuario][chave]
        exibir_progresso(tarefas)
        
        if not tarefas:
            print("""
            â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
            â•‘        ðŸŽ‰ TUDO EM DIA!             â•‘
            â• â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•£
            â•‘ Nenhuma tarefa pendente por aqui.  â•‘
            â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
            """)
        else:
            print("\nðŸ“‹ SUAS ATIVIDADES:\n")

            for idx, t in enumerate(tarefas, 1):
                status = "âœ…" if t["concluida"] else "â³"

                print(f"{idx}. {status} {t['titulo']}")

                for p in t.get("passos", []):
                    print(f"    â””â”€ ðŸ“Œ {p['texto']}")

                print()

        print("\n" + "-"*30)
        print("  â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—")
        print("     âžŠ ðŸ“ Adicionar â”‚  âž‹ Abrir Tarefa â”‚  âžŒ ðŸ¤– IA â”‚  âž ðŸ”™ Voltar      ")
        print("  â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•")
        opcao = input("\nEscolha uma opÃ§Ã£o: ").strip()

        if opcao == "1":
            print("\nðŸ¤– Certo! Vamos criar uma nova atividade.")
            t_nome = input("âžœ O que vocÃª precisa fazer hoje? ").strip()
            if t_nome:
                resposta = tarefa_controller.criar_tarefa(
                    usuario_nome=usuario,
                    tipo=chave,
                    titulo=t_nome
                )

                if not resposta["sucesso"]:
                    print(f"\n❌ {resposta['mensagem']}")
                    input("\nPressione ENTER para continuar...")
                    continue

                dados_atualizados = carregar_dados()
                dados.clear()
                dados.update(dados_atualizados)
                import random

                mensagens = [
                    "ðŸŒŸ Excelente! JÃ¡ anotei isso.",
                    "ðŸš€ Um passo de cada vez!",
                    "ðŸ“Œ Atividade adicionada com sucesso.",
                    "ðŸ’™ Pode deixar, estÃ¡ tudo anotado.",
                    "ðŸŽ¯ Agora ficou mais fÃ¡cil lembrar."
                ]

                print(f"\n{random.choice(mensagens)}")
                print(f"ðŸ“Œ {t_nome}")

                input("\nPressione ENTER para continuar...")
        elif opcao == "2" and tarefas:

            try:

                indice = int(input("\nQual tarefa deseja abrir? ")) - 1

                if 0 <= indice < len(tarefas):

                    abrir_tarefa_menu(
                        dados,
                        usuario,
                        chave,
                        indice
                    )

            except ValueError:
                print("\nNÃºmero invÃ¡lido.")
                input("\nENTER...")

def painel_ia_menu(dados: dict, usuario: str):
    exibir_cabecalho("ðŸ¤– IAMIGO")
    print("""
            â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
            â•‘        CONVERSA COM IAMIGO         â•‘
            â• â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•£
            â•‘  Pode me perguntar qualquer coisa! â•‘
            â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
            """)
    print("PeÃ§a ajuda para simplificar enunciados, organizar rotinas ou tirar dÃºvidas.")
    print("Digite 'sair' para retornar.\n")
    estilo = dados[usuario]["preferencias"]["estilo_instrucao"]

    while True:
        pergunta = input("\nVocÃª: ").strip()
        if pergunta.lower() == 'sair':
            print("\nðŸ‘‹ AtÃ© a prÃ³xima!")
            break
        if not pergunta: continue
        
        import random
        
        frases = [
            "ðŸ¤” Estou pensando...",
            "ðŸ§  Analisando sua pergunta...",
            "ðŸ“š Organizando a resposta...",
            "ðŸ’¡ Tenho uma ideia!",
            "ðŸŽ¯ Vamos simplificar isso..."
        ]

        print(f"\n{random.choice(frases)}")

        respostas = ia_service.obter_resposta_ia(pergunta, estilo)
        print("\nðŸ¤– IAmigo:")
        for linha in respostas:
            print(f"- {linha}")
        print("\nâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•")

def painel_principal_menu(dados: dict, usuario: str):
    while True:
        exibir_cabecalho("PAINEL DO USUÃRIO:")
        exibir_barra_status(usuario)

        print("""
        â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
        â•‘      COMO POSSO TE AJUDAR?         â•‘
        â• â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•£
        â•‘ 1. ðŸ“ Organizar minhas tarefas     â•‘
        â•‘ 2. ðŸ“š Planejar meus estudos        â•‘
        â•‘ 3. ðŸ¤– Conversar com o IAmigo       â•‘
        â•‘ 4. ðŸ‘‹ Encerrar por agora           â•‘
        â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        """)
        opcao = input("\nEscolha: ").strip()
        if opcao == "1":
            print("\nðŸ¤– Vamos colocar suas tarefas em ordem!")
            input("\nPressione ENTER para continuar...")
            gerenciar_tarefas_menu(dados, usuario, "tarefas_diarias", "ROTINA DIÃRIA")
        elif opcao == "2":
            print("\nðŸ¤– Ã“timo! Vamos focar nos estudos.")
            input("\nPressione ENTER para continuar...")
            gerenciar_tarefas_menu(dados, usuario, "tarefas_educacionais", "ESTUDOS E EDUCAÃ‡ÃƒO")
        elif opcao == "3":
            print("\nðŸ¤– Estou pronto para conversar com vocÃª!")
            input("\nPressione ENTER para continuar...")
            painel_ia_menu(dados, usuario)
        elif opcao == "4":
            print("\nðŸ¤– Foi muito bom conversar com vocÃª hoje.")
            print("ðŸ‘‹ AtÃ© a prÃ³xima!")
            break

def abrir_tarefa_menu(dados, usuario, chave, indice_tarefa):
    while True:

        tarefa = dados[usuario][chave][indice_tarefa]

        exibir_cabecalho("TAREFA")

        print(f"\nðŸ“ {tarefa['titulo']}\n")

        print("Subtarefas:\n")

        subtarefas = tarefa.get("subtarefas", [])

        if not subtarefas:
            print("Nenhuma subtarefa criada.")
        else:
            for i, sub in enumerate(subtarefas, 1):
                status = "â˜‘" if sub["concluida"] else "â˜"
                
                print(f"{i}. {status} {sub['titulo']}")

        print("\n" + "-" * 35)

        print("1 - Nova subtarefa")
        print("2 - Marcar subtarefa")
        print("3 - Excluir subtarefa")
        print("4 - Voltar")

        opcao = input("\nEscolha: ")

        if opcao == "4":
            break

        if opcao == "1":

            titulo = input("\nNome da subtarefa: ").strip()

            if titulo:

                core_tarefas.adicionar_subtarefa(

                    dados,

                    usuario,

                    chave,

                    indice_tarefa,

                    titulo

                )

                print("\nâœ… Subtarefa adicionada!")

                input("\nENTER...")


