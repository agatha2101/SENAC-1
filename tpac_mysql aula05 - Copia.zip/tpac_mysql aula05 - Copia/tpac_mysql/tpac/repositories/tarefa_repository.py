﻿from sqlalchemy import select

from config.database import SessionLocal
from models.tarefa import Tarefa


class TarefaRepository:
    def listar(self):
        with SessionLocal() as session:
            comando = select(Tarefa).order_by(
                Tarefa.id
            )
            return list(session.scalars(comando))

    def listar_por_usuario(
        self,
        usuario_id,
        tipo=None
    ):
        with SessionLocal() as session:
            comando = select(Tarefa).where(
                Tarefa.usuario_id == usuario_id
            )

            if tipo is not None:
                comando = comando.where(
                    Tarefa.tipo == tipo
                )

            comando = comando.order_by(Tarefa.id)
            return list(session.scalars(comando))

    def buscar_por_id(self, tarefa_id):
        with SessionLocal() as session:
            return session.get(Tarefa, tarefa_id)

    def criar(
        self,
        usuario_id,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None,
        concluida=False
    ):
        with SessionLocal() as session:
            tarefa = Tarefa(
                usuario_id=usuario_id,
                tipo=tipo,
                titulo=titulo,
                descricao=descricao,
                prioridade=prioridade,
                prazo=prazo,
                concluida=concluida
            )

            session.add(tarefa)
            session.commit()
            session.refresh(tarefa)

            return tarefa

    def atualizar_status(
        self,
        tarefa_id,
        concluida
    ):
        with SessionLocal() as session:
            tarefa = session.get(Tarefa, tarefa_id)

            if tarefa is None:
                return None

            tarefa.concluida = concluida
            session.commit()
            session.refresh(tarefa)

            return tarefa

    def excluir(self, tarefa_id):
        with SessionLocal() as session:
            tarefa = session.get(Tarefa, tarefa_id)

            if tarefa is None:
                return False

            session.delete(tarefa)
            session.commit()

            return True
