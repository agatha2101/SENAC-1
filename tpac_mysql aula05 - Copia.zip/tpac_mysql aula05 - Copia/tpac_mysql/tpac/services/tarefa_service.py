﻿from datetime import date, datetime

from repositories.tarefa_repository import TarefaRepository


class TarefaService:
    TIPOS_VALIDOS = [
        "tarefas_diarias",
        "tarefas_educacionais"
    ]

    PRIORIDADES_VALIDAS = [
        "baixa",
        "media",
        "alta"
    ]

    def __init__(self, repository=None):
        self.repository = repository or TarefaRepository()

    def listar_tarefas(
        self,
        usuario_id=None,
        tipo=None
    ):
        if tipo is not None:
            self._validar_tipo(tipo)

        if usuario_id is None:
            return self.repository.listar()

        return self.repository.listar_por_usuario(
            usuario_id,
            tipo
        )

    def criar_tarefa(
        self,
        usuario_id,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None
    ):
        titulo = titulo.strip()

        if not titulo:
            raise ValueError(
                "O título da tarefa é obrigatório."
            )

        if len(titulo) < 3:
            raise ValueError(
                "O título deve ter pelo menos 3 caracteres."
            )

        self._validar_tipo(tipo)
        self._validar_prioridade(prioridade)

        prazo_formatado = self._formatar_prazo(prazo)

        return self.repository.criar(
            usuario_id=usuario_id,
            tipo=tipo,
            titulo=titulo,
            descricao=descricao,
            prioridade=prioridade,
            prazo=prazo_formatado,
            concluida=False
        )

    def _validar_tipo(self, tipo):
        if tipo not in self.TIPOS_VALIDOS:
            raise ValueError(
                "Tipo de tarefa inválido."
            )

    def _validar_prioridade(self, prioridade):
        if prioridade not in self.PRIORIDADES_VALIDAS:
            raise ValueError(
                "Prioridade inválida."
            )

    def _formatar_prazo(self, prazo):
        if prazo is None or prazo == "":
            return None

        if isinstance(prazo, date):
            return prazo

        if isinstance(prazo, str):
            try:
                return datetime.strptime(
                    prazo,
                    "%Y-%m-%d"
                ).date()

            except ValueError:
                raise ValueError(
                    "Prazo inválido. Use AAAA-MM-DD."
                )

        raise ValueError(
            "Formato de prazo inválido."
        )