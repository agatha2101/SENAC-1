from data.data_manager import salvar_dados

def adicionar_tarefa(dados: dict, usuario: str, chave: str, titulo: str):
    dados[usuario][chave].append({
        "titulo": titulo,
        "concluida": False,
        "subtarefas": [],
        "progresso": 0
    })
    
    salvar_dados(dados)

def alternar_status_tarefa(dados: dict, usuario: str, chave: str, idx: int):
    tarefas = dados[usuario][chave]
    if 0 <= idx < len(tarefas):
        tarefas[idx]["concluida"] = not tarefas[idx]["concluida"]
        salvar_dados(dados)

def injetar_passos_ia(dados: dict, usuario: str, chave: str, idx: int, passos: list):
    tarefas = dados[usuario][chave]

    if 0 <= idx < len(tarefas):

        tarefas[idx]["subtarefas"] = [
            {
                "titulo": passo,
                "concluida": False
            }
            for passo in passos
        ]

        salvar_dados(dados)

def adicionar_subtarefa(dados, usuario, chave, indice_tarefa, titulo):

    tarefa = dados[usuario][chave][indice_tarefa]

    print("\nDEBUG:")
    print(tarefa)

    if "subtarefas" not in tarefa:
        tarefa["subtarefas"] = []

    tarefa["subtarefas"].append({
        "titulo": titulo,
        "concluida": False
    })

    salvar_dados(dados)