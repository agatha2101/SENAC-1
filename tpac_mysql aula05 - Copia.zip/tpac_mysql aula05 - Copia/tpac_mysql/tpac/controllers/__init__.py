from fastapi import APIRouter

from controllers.usuario_controller import UsuarioController

router = APIRouter(
    prefix="/usuarios",
    tags=["usuarios"]
)

controller = UsuarioController()


@router.get("")
def listar_usuarios():
    return {
        "dados": controller.listar_perfis()
    }