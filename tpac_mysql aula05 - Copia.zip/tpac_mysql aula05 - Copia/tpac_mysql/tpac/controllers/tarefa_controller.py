﻿from repositories.usuario_repository import UsuarioRepository
from services.tarefa_service import TarefaService


class TarefaController:
    def __init__(
        self,
        service=None,
        usuario_repository=None
    ):
    
        self.service = service or TarefaService()
        self.usuario_repository = (
            usuario_repository or UsuarioRepository()
        )

    def listar_tarefas(self):
        tarefas = self.service.listar_tarefas()

        return [
            {
                "id": tarefa.id,
                "usuario_id": tarefa.usuario_id,
                "tipo": tarefa.tipo,
                "titulo": tarefa.titulo,
                "descricao": tarefa.descricao,
                "prioridade": tarefa.prioridade,
                "prazo": tarefa.prazo,
                "concluida": tarefa.concluida,
                "criado_em": tarefa.criado_em
            }
            for tarefa in tarefas
        ]

    def criar_tarefa(
        self,
        usuario_nome,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None
    ):
        try:
            usuario = (
                self.usuario_repository.buscar_por_nome(
                    usuario_nome
                )
            )

            if usuario is None:
                raise ValueError(
                    "Usuário não encontrado."
                )

            tarefa = self.service.criar_tarefa(
                usuario_id=usuario.id,
                tipo=tipo,
                titulo=titulo,
                descricao=descricao,
                prioridade=prioridade,
                prazo=prazo
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": (
                    f"Atividade {tarefa.titulo} adicionada."
                )
            }

        except ValueError as erro:
                return {
                    "sucesso": False,
                    "tipo": "REGRA_NEGOCIO",
                    "mensagem": str(erro)
                }

        except Exception as erro:
            print("ERRO AO CRIAR TAREFA:", erro)

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível adicionar a atividade."
                )
            }