import unittest

from services.tarefa_service import TarefaService


class TarefaRepositoryFake:
    def __init__(self):
        self.tarefas_criadas = []

    def criar(self, **dados):
        self.tarefas_criadas.append(dados)
        return dados


class TestTarefaService(unittest.TestCase):
    def setUp(self):
        self.repository = TarefaRepositoryFake()
        self.service = TarefaService(
            repository=self.repository
        )

    def test_titulo_deve_ter_pelo_menos_3_caracteres(self):
        with self.assertRaisesRegex(
            ValueError,
            "pelo menos 3 caracteres"
        ):
            self.service.criar_tarefa(
                usuario_id=1,
                tipo="tarefas_diarias",
                titulo="AB"
            )

    def test_cria_tarefa_valida(self):
        tarefa = self.service.criar_tarefa(
            usuario_id=1,
            tipo="tarefas_diarias",
            titulo="Estudar Python",
            prioridade="media"
        )

        self.assertEqual(
            len(self.repository.tarefas_criadas),
            1
        )

        self.assertEqual(
            tarefa["titulo"],
            "Estudar Python"
        )

    def test_titulo_obrigatorio(self):
        with self.assertRaisesRegex(
            ValueError,
            "O título da tarefa é obrigatório."
    ):
            self.service.criar_tarefa(
                usuario_id=1,
                tipo="tarefas_diarias",
                titulo=""
            )


if __name__ == "__main__":
    unittest.main()