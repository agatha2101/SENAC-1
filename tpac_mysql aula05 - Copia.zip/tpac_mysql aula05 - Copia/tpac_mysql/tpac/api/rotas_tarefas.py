from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from controllers.tarefa_controller import TarefaController


router = APIRouter(
    prefix="/tarefas",
    tags=["tarefas"]
)

controller = TarefaController()


class NovaTarefa(BaseModel):
    usuario_nome: str
    tipo: str
    titulo: str
    descricao: str | None = None
    prioridade: str = "media"
    prazo: str | None = None


@router.get("")
def listar_tarefas():
    return {
        "dados": controller.listar_tarefas()
    }


@router.post("", status_code=status.HTTP_201_CREATED)
def criar_tarefa(dados: NovaTarefa):
    resposta = controller.criar_tarefa(
        usuario_nome=dados.usuario_nome,
        tipo=dados.tipo,
        titulo=dados.titulo,
        descricao=dados.descricao,
        prioridade=dados.prioridade,
        prazo=dados.prazo
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=422,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta