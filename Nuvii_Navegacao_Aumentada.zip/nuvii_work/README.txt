NUVII — FRONT-END ATUALIZADO

Como executar:
1. Extraia a pasta nuvii_work mantendo a estrutura de pastas.
2. Abra index.html no navegador ou execute com Live Server no VS Code.
3. É necessária conexão com a internet para carregar as fontes Google Fonts.

Atualizações deste adendo:
- Saudação acolhedora aleatória na tela inicial, com nome salvo no perfil e sem repetir a saudação imediatamente anterior.
- Títulos principais centralizados e remoção de título duplicado no calendário.
- Botões de adicionar tarefa e evento padronizados.
- Agenda do dia recolhível com transição suave, sem seta animada e com contagem de eventos manuais.
- Eventos podem ser criados, editados e excluídos; tarefas com prazo continuam aparecendo no calendário sem duplicação.
- Formulários compartilham o estilo translúcido.
- Paleta antiga violeta removida dos principais estilos, gráficos e indicador da navegação móvel.
- Gradiente de fundo alinhado à paleta turquesa.
- Botão discreto “Fechar conversa”.
- Perfil com seleção, prévia, substituição e remoção de foto.
- Alternância entre modo claro e modo escuro, com preferência salva neste navegador.
- Respeito à preferência de movimento reduzido do sistema.

Persistência e limitações:
- Tarefas deste protótipo são mantidas em memória e não sincronizam entre visitas.
- Eventos, nome do perfil, foto e tema são salvos no localStorage do navegador atual.
- A foto é comprimida e armazenada localmente; não é enviada a um servidor e não fica sincronizada entre dispositivos ou contas.
- O chat desta versão é demonstrativo e não possui integração real com uma API de IA.
- O projeto fornecido não contém autenticação nem back-end. Persistência vinculada à conta autenticada, upload remoto e chat real exigem infraestrutura e integração de servidor.
