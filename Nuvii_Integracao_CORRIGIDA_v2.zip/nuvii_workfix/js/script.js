document.body.dataset.currentPage='home';
const pageMeta={home:['','',''],tasks:['','Minhas tarefas',''],reports:['','Seu progresso',''],assistant:['','Converse com a Nuvii',''],profile:['','Meu perfil',''],calendar:['','Calendário','']};
let nextId=4,style='direto',quickTitle='',quickSteps=[],quickStage='',reportSelection=null;
let calendarEvents=[];try{calendarEvents=JSON.parse(localStorage.getItem('nuvii-calendar-events')||'[]')}catch{calendarEvents=[]}let nextEventId=calendarEvents.reduce((m,e)=>Math.max(m,Number(e.id)||0),0)+1;function persistCalendarEvents(){try{localStorage.setItem('nuvii-calendar-events',JSON.stringify(calendarEvents))}catch{toast('Não foi possível salvar o evento neste navegador.')}}
let tasks=[{id:1,title:'Estudar para a prova',desc:'Revisar os conteúdos e praticar exercícios.',type:'educacional',priority:'alta',date:'',startedAt:null,completedAt:null,done:false,steps:[{text:'Separar o material necessário',done:true},{text:'Revisar o conteúdo principal',done:false},{text:'Praticar exercícios',done:false}]},{id:2,title:'Organizar o quarto',desc:'Separar objetos e deixar tudo no lugar.',type:'diaria',priority:'media',date:'',startedAt:null,completedAt:null,done:false,steps:[{text:'Separar o que precisa ser organizado',done:false},{text:'Organizar por partes',done:false}]},{id:3,title:'Pagar uma conta',desc:'Conferir o vencimento e realizar o pagamento.',type:'diaria',priority:'baixa',date:'',startedAt:null,completedAt:null,done:true,steps:[]}];
// Persistência local do protótipo: mantém tarefas e subtarefas após recarregar.
try { const savedTasks=JSON.parse(localStorage.getItem('nuvii-tasks')||'null'); if(Array.isArray(savedTasks)) tasks=savedTasks; } catch {}
nextId=Math.max(nextId,...tasks.map(t=>(Number(t.id)||0)+1));
function persistTasks(){try{localStorage.setItem('nuvii-tasks',JSON.stringify(tasks));}catch{toast('Não foi possível salvar as tarefas neste navegador.');}}

const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
function toast(message){const old=$('.toast');if(old)old.remove();const el=document.createElement('div');el.className='toast';el.textContent=message;document.body.append(el);setTimeout(()=>el.remove(),2400)}
function navigate(page){$$('.page').forEach(p=>p.classList.remove('active'));$('#page-'+page).classList.add('active');$$('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));const nav=$('.mobile-nav');if(nav){const bs=[...nav.querySelectorAll('button[data-page]')],i=bs.findIndex(b=>b.dataset.page===page);if(i>=0)nav.style.setProperty('--nav-index',i)}const m=pageMeta[page];$('#eyebrow').textContent='';$('#page-title').textContent=page==='home'?'':m[1];$('#page-sub').textContent='';document.body.dataset.currentPage=page;const companion=document.getElementById('nuvii-companion');if(companion){companion.style.display=page==='home'?'none':'flex';} $('#add-task').style.display=page==='tasks'?'inline-flex':'none';$('.topline-actions .avatar').style.display=page==='tasks'?'none':'grid';if(page==='tasks')renderTasks();if(page==='reports')renderStats();if(page==='calendar')renderCalendar();window.scrollTo({top:0,behavior:'auto'})}
$$('[data-page]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
$$('[data-report-view]').forEach(b=>b.addEventListener('click',()=>{const type=b.dataset.reportView;if(reportSelection?.type===type){closeReportDetails();return}showReportDetail(type);setTimeout(()=>b.closest('.report-stat')?.scrollIntoView({behavior:'smooth',block:'nearest'}),60)}));
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function progress(t){return t.steps.length?Math.round(t.steps.filter(s=>s.done).length/t.steps.length*100):(t.done?100:0)}
function renderTasks(){const host=$('#task-list');host.innerHTML='';const q=($('#task-search')?.value||'').trim().toLocaleLowerCase('pt-BR');const selected=group=>$$('[data-filter-group="'+group+'"]:checked').map(el=>el.value);const categories=selected('category'),priorities=selected('priority'),statuses=selected('status');const type=$('#task-type-filter')?.value||'all';const priority=$('#task-priority-filter')?.value||'all';const status=$('#task-status-filter')?.value||'all';const visible=tasks.filter(t=>(!q||(t.title+' '+(t.desc||'')).toLocaleLowerCase('pt-BR').includes(q))&&(!categories.length?type==='all'||t.type===type:categories.includes(t.type))&&(!priorities.length?priority==='all'||t.priority===priority:priorities.includes(t.priority))&&(!statuses.length?status==='all'||(status==='done'?t.done:!t.done):statuses.includes(t.done?'done':'pending')));const empty=$('#task-empty');if(empty)empty.hidden=visible.length!==0;visible.forEach((t,i)=>{const pct=progress(t),el=document.createElement('article');el.className='task';el.style.animationDelay=(i*.06)+'s';el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-label','Abrir tarefa '+t.title);el.innerHTML=`<div class="task-top"><h3>${escapeHtml(t.title)}</h3><span class="tag ${t.priority==='alta'?'high':t.priority==='baixa'?'low':''}">${({alta:'Alta',media:'Média',baixa:'Baixa'})[t.priority]||t.priority}</span></div><p class="task-description">${escapeHtml(t.desc||'Sem descrição.')}</p><div class="progress"><span style="width:${t.done?100:pct}%"></span></div><div class="task-foot"><span>${t.done?'Concluída':pct+'% concluído'} · ${t.steps.length} subtarefa(s)</span><button class="complete-btn" data-complete="${t.id}">${t.done?'✓ Concluída':'Marcar concluída'}</button></div>`;el.addEventListener('click',e=>{if(!e.target.closest('[data-complete]'))openDetail(t.id)});el.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target===el){e.preventDefault();openDetail(t.id)}});host.append(el)});host.querySelectorAll('[data-complete]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();toggleTask(+b.dataset.complete)}))}
function localISODate(d=new Date()){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
function parseLocalDate(value){if(!value)return new Date();const [y,m,d]=value.split('-').map(Number);return new Date(y,m-1,d)}
function formatDate(value){if(!value)return 'Data não registrada';const d=new Date(value+'T12:00:00');return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'}).replace('.','')}
function daysBetween(a,b){if(!a||!b)return null;const start=new Date(a+'T12:00:00'),end=new Date(b+'T12:00:00');return Math.max(0,Math.round((end-start)/86400000))}
function workWeek(){const now=new Date(),day=now.getDay(),monday=new Date(now);monday.setDate(now.getDate()-(day===0?6:day-1));return Array.from({length:5},(_,i)=>{const d=new Date(monday);d.setDate(monday.getDate()+i);return {date:localISODate(d),short:['Seg','Ter','Qua','Qui','Sex'][i],label:['segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira'][i]}})}
function reportRow(t,mode){const pct=t.done?100:progress(t),doneSteps=t.steps.filter(s=>s.done).length,totalSteps=t.steps.length;let meta='';if(mode==='completed'){const duration=daysBetween(t.startedAt||t.completedAt,t.completedAt);meta=`<span>▶ Início: ${escapeHtml(formatDate(t.startedAt))}</span><span>✓ Conclusão: ${escapeHtml(formatDate(t.completedAt))}</span><span>◷ ${duration===null?'Duração não registrada':duration===0?'Concluída no mesmo dia':duration+' '+(duration===1?'dia decorrido':'dias decorridos')}</span>`}else{meta=`<span>${doneSteps} de ${totalSteps} subtarefas concluídas</span><span>${totalSteps-doneSteps} ${totalSteps-doneSteps===1?'etapa restante':'etapas restantes'}</span>`}return `<article class="report-row"><div class="report-row-top"><h3 class="report-row-title">${escapeHtml(t.title)}</h3>${mode==='completed'||t.done?'<span class="tag low">Concluída</span>':`<span class="report-summary-pill">${pct}%</span>`}</div><div class="report-row-meta">${meta}</div>${mode!=='completed'?`<div class="report-progress" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="Progresso de ${escapeHtml(t.title)}"><span style="width:${pct}%"></span></div><div class="report-progress-label"><span>${totalSteps?`${doneSteps}/${totalSteps} subtarefas feitas`:'Nenhuma subtarefa cadastrada'}</span><strong>${pct}%</strong></div>`:''}</article>`}
function closeReportDetails(){reportSelection=null;$$('[data-report-view]').forEach(b=>b.setAttribute('aria-expanded','false'));$$('.report-stat').forEach(card=>card.classList.remove('is-expanded'));$$('.report-card-details').forEach(panel=>{panel.classList.remove('is-open');setTimeout(()=>{if(!panel.classList.contains('is-open'))panel.hidden=true},440)});const chartPanel=$('#report-detail');if(chartPanel){chartPanel.hidden=true;chartPanel.classList.remove('is-open')}$$('.chart-day').forEach(b=>b.setAttribute('aria-pressed','false'));}
function showReportDetail(type,date=null){closeReportDetails();reportSelection={type,date};renderReportDetail();$$('[data-report-view]').forEach(b=>b.setAttribute('aria-expanded',String(b.dataset.reportView===type)));if(type!=='day'){const card=$(`[data-report-card="${type}"]`),panel=$(`#report-detail-${type}`);card?.classList.add('is-expanded');if(panel){panel.hidden=false;requestAnimationFrame(()=>panel.classList.add('is-open'))}}}
function renderReportDetail(){if(!reportSelection)return;const type=reportSelection.type;const panel=type==='day'?$('#report-detail'):$(`#report-detail-${type}`);if(!panel)return;panel.hidden=false;let title='',subtitle='',items=[],summary='';const total=tasks.length,done=tasks.filter(t=>t.done),open=tasks.filter(t=>!t.done),started=open.filter(t=>Boolean(t.startedAt)||t.steps.some(s=>s.done)),notStarted=open.filter(t=>!t.startedAt&&!t.steps.some(s=>s.done)),overall=total?Math.round(done.length/total*100):0;
 if(type==='completed'){title='Tarefas concluídas';subtitle='Veja quando cada tarefa começou, quando terminou e quanto tempo levou.';items=done.slice().sort((a,b)=>(b.completedAt||'').localeCompare(a.completedAt||''));summary=`<span class="report-summary-pill">${done.length} concluída(s)</span><span class="report-summary-pill">${overall}% do total</span>`;}
 else if(type==='overall'){title='Progresso geral de todas as tarefas';subtitle='Veja todas as tarefas, concluídas ou não, e quanto falta para finalizar cada uma.';items=tasks.slice().sort((a,b)=>Number(a.done)-Number(b.done));summary=`<span class="report-summary-pill">${done.length} de ${total} concluídas</span><span class="report-summary-pill">${overall}% concluído</span><span class="report-summary-pill">${open.length} restante(s)</span>`;}
 else if(type==='ongoing'){title='Tarefas já iniciadas';subtitle='Aqui aparecem somente tarefas em que o trabalho já começou. As que ainda não foram iniciadas ficam fora desta lista.';items=started.slice().sort((a,b)=>(b.startedAt||'').localeCompare(a.startedAt||''));summary=`<span class="report-summary-pill">${started.length} iniciada(s)</span><span class="report-summary-pill">${notStarted.length} aguardando início</span>`;}
 else if(type==='day'){const day=reportSelection.date;const dayInfo=workWeek().find(d=>d.date===day);title='Conclusões de '+formatDate(day);subtitle=dayInfo?`Tarefas concluídas na ${dayInfo.label}.`:'Tarefas concluídas nesta data.';items=done.filter(t=>t.completedAt===day);summary=`<span class="report-summary-pill">${items.length} concluída(s) neste dia</span>`;}
 const mode=type==='completed'||type==='day'?'completed':'progress';panel.innerHTML=`<div class="report-detail-head"><div><h2>${title}</h2><p>${subtitle}</p></div><button type="button" class="report-detail-close" aria-label="Fechar detalhes">×</button></div><div class="report-summary">${summary}</div><div class="report-detail-list">${items.length?items.map(t=>reportRow(t,mode)).join(''):`<div class="report-empty">${type==='day'?'Nenhuma tarefa foi registrada como concluída neste dia.':type==='completed'?'Ainda não há tarefas concluídas.':type==='ongoing'?'Nenhuma tarefa iniciada no momento.':'Nenhuma tarefa cadastrada ainda.'}</div>`}</div>`;panel.querySelector('.report-detail-close').addEventListener('click',closeReportDetails);if(type==='day'){$$('.chart-day').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chartDay===reportSelection.date)))}else{$$('.chart-day').forEach(b=>b.setAttribute('aria-pressed','false'));const card=$(`[data-report-card="${type}"]`);card?.classList.add('is-expanded')}}
function renderStats(){const done=tasks.filter(t=>t.done).length,total=tasks.length,open=total-done,started=tasks.filter(t=>!t.done&&(Boolean(t.startedAt)||t.steps.some(s=>s.done))).length;$('#done-count').textContent=done;const totalEl=$('#total-count');if(totalEl)totalEl.textContent=total;$('#progress-count').textContent=(total?Math.round(done/total*100):0)+'%';$('#open-count').textContent=started;const chart=$('#report-chart');if(chart){const days=workWeek(),counts=days.map(d=>tasks.filter(t=>t.done&&t.completedAt===d.date).length),max=Math.max(1,...counts);chart.innerHTML=days.map((d,i)=>`<button type="button" class="chart-day" data-chart-day="${d.date}" aria-pressed="${reportSelection?.type==='day'&&reportSelection.date===d.date?'true':'false'}" aria-label="${d.label}, ${counts[i]} tarefa(s) concluída(s)"><span class="chart-count">${counts[i]}</span><span class="bar" style="height:${Math.max(7,Math.round(counts[i]/max*118))}px"></span><span class="chart-label">${d.short} ${d.date.slice(8,10)}</span></button>`).join('');chart.querySelectorAll('[data-chart-day]').forEach(b=>b.addEventListener('click',()=>showReportDetail('day',b.dataset.chartDay)))}if(reportSelection)renderReportDetail()}
function openTaskModal(){$('#task-modal').classList.add('show');setTimeout(()=>$('#task-title').focus(),80)}function closeTaskModal(){$('#task-modal').classList.remove('show')}
$('#add-task').addEventListener('click',openTaskModal);$('#cancel-task').addEventListener('click',closeTaskModal);$('#task-modal').addEventListener('click',e=>{if(e.target===$('#task-modal'))closeTaskModal()});
$('#task-form').addEventListener('submit',e=>{e.preventDefault();const title=$('#task-title').value.trim();if(!title)return;tasks.unshift({id:nextId++,title,desc:$('#task-desc').value.trim(),type:$('#task-type').value,priority:$('#task-priority').value,date:$('#task-date').value,startedAt:null,completedAt:null,done:false,steps:[]});e.target.reset();closeTaskModal();renderTasks();renderStats();navigate('tasks');toast('Tarefa adicionada!')});
function openDetail(id){const t=tasks.find(x=>x.id===id);if(!t)return;const pct=progress(t);$('#detail-content').innerHTML=`<div class="eyebrow">DETALHES DA TAREFA</div><h2 id="detail-title">${escapeHtml(t.title)}</h2><p class="sub">${escapeHtml(t.desc||'Sem descrição por enquanto.')}</p><div class="detail-meta"><span class="tag ${t.priority==='alta'?'high':t.priority==='baixa'?'low':''}">${({alta:'Alta',media:'Média',baixa:'Baixa'})[t.priority]} prioridade</span><span class="tag">${t.type==='educacional'?'Educacional':'Diária'}</span>${t.date?`<span class="tag">Prazo ${escapeHtml(new Date(t.date+'T12:00:00').toLocaleDateString('pt-BR'))}</span>`:''}</div><div class="progress"><span style="width:${t.done?100:pct}%"></span></div><p class="sub">${t.steps.filter(s=>s.done).length} de ${t.steps.length} subtarefas concluídas</p><div id="detail-steps">${t.steps.map((step,i)=>`<div class="task-detail-step ${step.done?'done':''}"><input type="checkbox" id="step-${i}" data-step="${i}" ${step.done?'checked':''}><label for="step-${i}">${escapeHtml(step.text)}</label><button type="button" class="quick-close" data-remove-step="${i}" aria-label="Remover subtarefa">✕</button></div>`).join('')||'<p class="sub">Ainda não há subtarefas. Adicione uma abaixo.</p>'}</div><form class="detail-add-step" id="detail-step-form"><input id="detail-step-input" placeholder="Adicionar uma subtarefa..." aria-label="Nova subtarefa"><button class="primary" aria-label="Adicionar subtarefa">＋</button></form><div class="modal-actions"><button class="secondary" id="detail-close">Fechar</button><button class="primary" id="detail-finish">${t.done?'Reabrir tarefa':'Concluir tarefa'}</button></div>`;$('#detail-modal').classList.add('show');$('#detail-close').onclick=closeDetail;$('#detail-finish').onclick=()=>{t.done=!t.done;if(t.done){t.steps.forEach(s=>s.done=true);t.completedAt=localISODate();if(!t.startedAt)t.startedAt=localISODate()}else{t.completedAt=null}openDetail(id);renderTasks();renderStats();toast(t.done?'Tarefa concluída!':'Tarefa reaberta.')};$('#detail-step-form').onsubmit=e=>{e.preventDefault();const input=$('#detail-step-input'),text=input.value.trim();if(!text)return;t.steps.push({text,done:false});openDetail(id);renderTasks();renderStats();toast('Subtarefa adicionada')};$$('[data-step]').forEach(box=>box.addEventListener('change',()=>{t.steps[+box.dataset.step].done=box.checked;if(box.checked&&!t.startedAt)t.startedAt=localISODate();t.done=t.steps.length>0&&t.steps.every(s=>s.done);if(t.done){t.completedAt=localISODate();if(!t.startedAt)t.startedAt=localISODate()}else{t.completedAt=null}openDetail(id);renderTasks();renderStats()}));$$('[data-remove-step]').forEach(btn=>btn.addEventListener('click',()=>{t.steps.splice(+btn.dataset.removeStep,1);t.done=t.steps.length>0&&t.steps.every(s=>s.done);if(t.done){t.completedAt=localISODate();if(!t.startedAt)t.startedAt=localISODate()}else{t.completedAt=null}openDetail(id);renderTasks();renderStats()}))}
function closeDetail(){$('#detail-modal').classList.remove('show')}$('#detail-modal').addEventListener('click',e=>{if(e.target===$('#detail-modal'))closeDetail()});function toggleTask(id){const t=tasks.find(x=>x.id===id);t.done=!t.done;if(t.done){t.steps.forEach(s=>s.done=true);t.completedAt=localISODate();if(!t.startedAt)t.startedAt=localISODate()}else{t.completedAt=null}renderTasks();renderStats();toast(t.done?'Tarefa concluída!':'Tarefa reaberta.')}
function addMessage(host,text,who){const el=document.createElement('div');el.className='msg '+who;el.textContent=text;host.append(el);host.scrollTop=host.scrollHeight}
function suggestSteps(title){const s=title.toLowerCase();if(/estud|prova|revis|matéria|materia|escola|ler/.test(s))return ['Separar o material necessário','Revisar o conteúdo principal','Praticar exercícios'];if(/limp|organ|arrum|mochila|quarto|casa/.test(s))return ['Separar o que precisa ser organizado','Organizar por partes','Conferir se ficou tudo no lugar'];if(/compr|mercado|loja|buscar/.test(s))return ['Conferir o que precisa','Verificar opções e valores','Realizar a compra'];return ['Planejar o que precisa ser feito','Realizar a tarefa por etapas','Conferir o resultado']}
function closeQuick(){if(window.NuviiEmotionController)window.NuviiEmotionController.endConversation();quickStage='';quickTitle='';quickSteps=[];$('#quick-messages').innerHTML='<div class="msg bot">O que você precisa fazer? Escreva só o nome da tarefa. Eu ajudo com o resto.</div>';$('#quick-messages').classList.remove('expanded');$('.chat-panel').classList.remove('quick-expanded');$('#quick-input').value='';$('#quick-input').placeholder='Ex.: estudar para a prova...';$('.chat-panel .chips').hidden=false;const close=$('#quick-close-row');if(close)close.remove()}
function quickActions(actions){const host=$('#quick-messages'),row=document.createElement('div');row.style.cssText='display:flex;gap:8px;flex-wrap:wrap;animation:msgIn .3s both';actions.forEach(([label,fn])=>{const b=document.createElement('button');b.type='button';b.className='chip';b.textContent=label;b.onclick=fn;row.append(b)});host.append(row);host.scrollTop=host.scrollHeight}
function scrollQuickIntoView(){const panel=$('#page-home .chat-panel');if(!panel||!window.matchMedia('(max-width: 900px)').matches)return;const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;window.setTimeout(()=>{panel.scrollIntoView({behavior:reduce?'auto':'smooth',block:'start'});},70)}
function startQuick(text){text=(text||'').trim();if(!text)return;if(window.NuviiEmotionController)window.NuviiEmotionController.thinking();const host=$('#quick-messages');quickTitle=text;quickSteps=[];quickStage='choice';host.innerHTML='';host.classList.add('expanded');$('#page-home .chat-panel').classList.add('quick-expanded');scrollQuickIntoView();$('#page-home .chat-panel .chips').hidden=true;addMessage(host,text,'user');const closeRow=document.createElement('div');closeRow.className='quick-close-row';closeRow.id='quick-close-row';closeRow.innerHTML='<button class="quick-close" type="button">Fechar conversa ×</button>';host.after(closeRow);closeRow.querySelector('button').onclick=closeQuick;setTimeout(()=>{addMessage(host,'Certo! Vou organizar isso como uma tarefa. ✨ Quer que eu sugira algumas subtarefas para facilitar o começo?','bot');quickActions([['Sugerir subtarefas',showSuggested],['Salvar sem subtarefas',()=>saveQuick([])]])},260)}
function showSuggested(){quickSteps=suggestSteps(quickTitle);quickStage='suggested';const host=$('#quick-messages');addMessage(host,'Pensei nestas etapas para você:\n• '+quickSteps.join('\n• '),'bot');addMessage(host,'Você pode salvar assim ou escrever suas próprias etapas separadas por vírgulas.','bot');quickActions([['Salvar com essas etapas',()=>saveQuick(quickSteps)],['Editar etapas',()=>{quickStage='edit';addMessage(host,'Escreva as etapas separadas por vírgulas.','bot');$('#quick-input').placeholder='Etapa 1, etapa 2, etapa 3...';$('#quick-input').focus()}]])}
function saveQuick(steps){if(!quickTitle)return;const title=quickTitle,type=/estud|prova|escola|matéria|materia|aula|ler/.test(title.toLowerCase())?'educacional':'diaria';tasks.unshift({id:nextId++,title,desc:'Criada rapidamente pelo chat do Início.',type,priority:'media',date:'',startedAt:null,completedAt:null,done:false,steps:steps.map(text=>({text,done:false}))});renderTasks();renderStats();if(window.NuviiEmotionController)window.NuviiEmotionController.taskAdded();addMessage($('#quick-messages'),'Pronto! ✨ Registrei “'+title+'” nas suas tarefas'+(steps.length?' com '+steps.length+' subtarefas.':'.'),'bot');quickStage='finished';quickActions([['Abrir tarefa',()=>{const id=tasks[0].id;closeQuick();navigate('tasks');openDetail(id)}],['Fechar conversa',closeQuick]]);toast('Tarefa adicionada')}
function handleQuick(text){text=(text||'').trim();if(!text)return;addMessage($('#quick-messages'),text,'user');$('#quick-input').value='';if(quickStage==='choice'){if(/^(não|nao|salvar|salva|sem subtarefa|sem etapas)/i.test(text)){saveQuick([]);return}showSuggested();return}if(quickStage==='suggested'||quickStage==='edit'){const steps=text.split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean);if(steps.length){saveQuick(steps);return}addMessage($('#quick-messages'),'Escreva uma ou mais subtarefas separadas por vírgulas.','bot')}}
$('#quick-form').addEventListener('submit',e=>{e.preventDefault();if(quickStage)handleQuick($('#quick-input').value);else startQuick($('#quick-input').value)});$$('[data-prompt]').forEach(b=>b.addEventListener('click',()=>startQuick(b.dataset.prompt)));
$('#ai-form').addEventListener('submit',e=>{e.preventDefault();const input=$('#ai-input'),value=input.value.trim();if(!value)return;input.value='';const host=$('#ai-messages');addMessage(host,value,'user');if(window.NuviiEmotionController)window.NuviiEmotionController.thinking();setTimeout(()=>addMessage(host,'Entendi. ✨ Vamos organizar isso com calma, um passo de cada vez. Esta resposta é ilustrativa; a integração com a IA será feita posteriormente.','bot'),420)});
$('#save-profile').addEventListener('click',()=>{const name=$('#profile-name').value.trim()||'Amigo';$('.avatar').textContent=name.charAt(0).toUpperCase();localStorage.setItem('nuvii-profile-name',name);if(document.body.dataset.currentPage==='home')$('#page-title').textContent=name;toast('Preferências salvas neste protótipo')});
$('#task-search').addEventListener('input',renderTasks);
$('#filters-toggle').addEventListener('click',()=>{const btn=$('#filters-toggle'),panel=$('#filters-panel'),open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',String(!open));panel.hidden=open;});
function updateFilterCount(){const n=$$('[data-filter-group]:checked').length;$('#filter-count').textContent=n;$('#filter-count').hidden=n===0;}
$$('[data-filter-group]').forEach(box=>box.addEventListener('change',()=>{updateFilterCount();renderTasks()}));
$('#clear-filters').addEventListener('click',()=>{$$('[data-filter-group]').forEach(box=>box.checked=false);$('#task-type-filter').value='all';$('#task-priority-filter').value='all';$('#task-status-filter').value='all';updateFilterCount();renderTasks()});
$('#apply-filters').addEventListener('click',()=>{$('#filters-panel').hidden=true;$('#filters-toggle').setAttribute('aria-expanded','false');renderTasks()});

// Calendário: reúne tarefas com prazo e eventos criados pela pessoa usuária.
let calendarCursor=new Date();calendarCursor.setDate(1);let selectedCalendarDate=localISODate();
function allCalendarItems(date){const taskItems=tasks.filter(t=>t.date===date).map(t=>({kind:'task',id:t.id,title:t.title,desc:t.desc||'',date:t.date,time:'',type:t.type==='educacional'?'Estudos':'Tarefa',done:t.done}));const eventItems=calendarEvents.filter(e=>e.date===date).map(e=>({...e,kind:'event',type:'Evento',done:false}));return [...taskItems,...eventItems].sort((a,b)=>(a.time||'99:99').localeCompare(b.time||'99:99')||a.title.localeCompare(b.title,'pt-BR'))}
function renderCalendar(){if(!$('#calendar-days'))return;const year=calendarCursor.getFullYear(),month=calendarCursor.getMonth();$('#calendar-month').textContent=calendarCursor.toLocaleDateString('pt-BR',{month:'long',year:'numeric'});const first=new Date(year,month,1),offset=(first.getDay()+6)%7,days=new Date(year,month+1,0).getDate(),host=$('#calendar-days');host.innerHTML='';for(let i=0;i<offset;i++){const blank=document.createElement('span');blank.className='calendar-blank';blank.setAttribute('aria-hidden','true');host.append(blank)}for(let day=1;day<=days;day++){const date=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`,items=allCalendarItems(date),btn=document.createElement('button');btn.type='button';btn.className='calendar-day'+(date===localISODate()?' is-today':'')+(date===selectedCalendarDate?' is-selected':'')+(items.length?' has-items':'')+(items.length&&items.every(x=>x.done)?' all-done':'');btn.textContent=day;btn.setAttribute('aria-label',formatDate(date)+(items.length?`, ${items.length} item(ns)`:''));btn.setAttribute('aria-pressed',String(date===selectedCalendarDate));if(items.length){const dot=document.createElement('i');dot.className='calendar-dot';dot.setAttribute('aria-hidden','true');btn.append(dot)}btn.addEventListener('click',()=>{selectedCalendarDate=date;renderCalendar()});host.append(btn)}
const selected=parseLocalDate(selectedCalendarDate),isToday=selectedCalendarDate===localISODate();$('#agenda-title').textContent='Agenda do dia';$('#agenda-date').textContent=formatDate(selectedCalendarDate,{day:'numeric',month:'short'});const items=allCalendarItems(selectedCalendarDate);const eventCount=calendarEvents.filter(e=>e.date===selectedCalendarDate).length;$('#agenda-count').textContent=`${eventCount} ${eventCount===1?'evento':'eventos'}`;const agenda=$('#agenda-items');const wasOpen=$('#agenda-toggle').getAttribute('aria-expanded')==='true';agenda.hidden=false;agenda.innerHTML='';if(!items.length)agenda.innerHTML='<div class="calendar-empty"><span>✳</span><strong>Nenhum item nesta data.</strong><p>Não há eventos ou tarefas com prazo para este dia.</p></div>';else items.forEach(item=>{const card=document.createElement('article');card.className='agenda-item'+(item.done?' is-done':'');card.innerHTML=`<div class="agenda-time">${item.time?escapeHtml(item.time):item.done?'✓':'•'}</div><div class="agenda-item-content"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.desc||item.type||'')}</p><div class="agenda-tags"><span class="mini-tag">${escapeHtml(item.type||'Evento')}</span><span class="mini-tag ${item.done?'done-tag':''}">${item.done?'Concluída':item.kind==='event'?'Evento':'Tarefa pendente'}</span></div></div><div class="agenda-item-actions">${item.kind==='task'?`<button type="button" data-open-task="${item.id}">Ver tarefa</button>`:`<button type="button" data-edit-event="${item.id}">Editar</button><button type="button" data-delete-event="${item.id}">Excluir evento</button>`}</div>`;agenda.append(card)});if(wasOpen){agenda.classList.add('is-open');agenda.style.maxHeight='none';}else{agenda.classList.remove('is-open');agenda.style.maxHeight='0px';agenda.hidden=true;}agenda.querySelectorAll('[data-edit-event]').forEach(btn=>btn.addEventListener('click',()=>openEventModal(btn.dataset.editEvent)));agenda.querySelectorAll('[data-delete-event]').forEach(btn=>btn.addEventListener('click',()=>{calendarEvents=calendarEvents.filter(e=>e.id!==Number(btn.dataset.deleteEvent));persistCalendarEvents();renderCalendar();toast('Evento excluído.')}));}
$('#agenda-toggle').addEventListener('click',()=>{const agenda=$('#agenda-items'),open=$('#agenda-toggle').getAttribute('aria-expanded')==='true';$('#agenda-toggle').setAttribute('aria-expanded',String(!open));if(!open){agenda.hidden=false;agenda.classList.add('is-open');agenda.style.maxHeight='0px';requestAnimationFrame(()=>{agenda.style.maxHeight=agenda.scrollHeight+'px';});}else{agenda.style.maxHeight=agenda.scrollHeight+'px';requestAnimationFrame(()=>{agenda.classList.remove('is-open');agenda.style.maxHeight='0px';});}});
$('#agenda-items').addEventListener('transitionend',e=>{if(e.propertyName!=='max-height')return;const agenda=e.currentTarget;if($('#agenda-toggle').getAttribute('aria-expanded')==='false'){agenda.hidden=true;}else{agenda.style.maxHeight='none';}});
let editingEventId=null;
function openEventModal(eventId=null){const modal=$('#event-modal');$('#event-form').reset();editingEventId=eventId===null?null:Number(eventId);const existing=editingEventId===null?null:calendarEvents.find(e=>Number(e.id)===editingEventId);$('#event-modal-title').textContent=existing?'Editar evento':'Novo evento';$('#event-title').value=existing?.title||'';$('#event-desc').value=existing?.desc||'';$('#event-date').value=existing?.date||selectedCalendarDate||localISODate();$('#event-time').value=existing?.time||'';modal.classList.add('show');setTimeout(()=>$('#event-title').focus(),80)}
function closeEventModal(){$('#event-modal').classList.remove('show');editingEventId=null}
$('#add-event').addEventListener('click',()=>openEventModal());$('#cancel-event').addEventListener('click',closeEventModal);$('#event-modal').addEventListener('click',e=>{if(e.target===$('#event-modal'))closeEventModal()});$('#event-form').addEventListener('submit',e=>{e.preventDefault();const title=$('#event-title').value.trim(),date=$('#event-date').value;if(!title||!date){toast('Preencha o nome e a data do evento.');return}const record={title,desc:$('#event-desc').value.trim(),date,time:$('#event-time').value};if(editingEventId!==null){const index=calendarEvents.findIndex(item=>Number(item.id)===editingEventId);if(index<0){toast('Este evento não foi encontrado.');closeEventModal();return}calendarEvents[index]={...calendarEvents[index],...record};}else{calendarEvents.push({id:nextEventId++,...record})}persistCalendarEvents();selectedCalendarDate=date;const d=parseLocalDate(date);calendarCursor=new Date(d.getFullYear(),d.getMonth(),1);const wasEditing=editingEventId!==null;closeEventModal();renderCalendar();toast(wasEditing?'Evento atualizado!':'Evento adicionado ao calendário!')});
$('#month-prev').addEventListener('click',()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()});$('#month-next').addEventListener('click',()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()});$('#go-today').addEventListener('click',()=>{selectedCalendarDate=localISODate();calendarCursor=new Date();calendarCursor.setDate(1);renderCalendar()});
document.addEventListener('click',e=>{const task=e.target.closest('[data-open-task]');if(task){navigate('tasks');openDetail(+task.dataset.openTask)}});

renderTasks();renderStats();renderCalendar();

// Perfil local e saudação da tela inicial.
const profileNameField=$('#profile-name');
if(profileNameField){const savedProfileName=localStorage.getItem('nuvii-profile-name');if(savedProfileName)profileNameField.value=savedProfileName;profileNameField.addEventListener('input',()=>{if(document.body.dataset.currentPage==='home')$('#page-title').textContent=profileNameField.value.trim()||'Olá';});$('#save-profile')?.addEventListener('click',()=>{const name=profileNameField.value.trim();if(name){localStorage.setItem('nuvii-profile-name',name);if(document.body.dataset.currentPage==='home')$('#page-title').textContent=name;}});}

// Saudações: uma escolha por carregamento/visita, sem alternância durante a navegação.
(function setupHomeGreeting(){
  const field=$('#profile-name'), host=$('#home-greeting');
  if(!host) return;
  const greetings=[
    name=>`Olá, ${name}!`, name=>`Como vai, ${name}?`,
    name=>`Que bom ter você aqui, ${name}!`, name=>`Oi, ${name}! Como você está?`,
    name=>`Vamos começar, ${name}?`, name=>`Que bom ver você por aqui, ${name}!`, name=>`Tudo bem, ${name}?`
  ];
  const fallback=['Olá!','Que bom ter você aqui!','Vamos começar?','Que bom ver você por aqui!'];
  const savedName=localStorage.getItem('nuvii-profile-name');
  if(savedName&&field) field.value=savedName;
  const name=(savedName||field?.value||'').trim();
  const topAvatar=$('.topline-actions .avatar');
  if(topAvatar&&name) topAvatar.textContent=name.charAt(0).toLocaleUpperCase('pt-BR');
  const previous=localStorage.getItem('nuvii-last-greeting-index');
  const pool=Array.from({length:greetings.length},(_,i)=>i).filter(i=>String(i)!==previous);
  const index=pool[Math.floor(Math.random()*pool.length)]??0;
  localStorage.setItem('nuvii-last-greeting-index',String(index));
  host.textContent=name?greetings[index](name):fallback[index%fallback.length];
  const refreshName=()=>{const n=(field?.value||localStorage.getItem('nuvii-profile-name')||'').trim();host.textContent=n?greetings[index](n):fallback[index%fallback.length];};
  field?.addEventListener('input',refreshName);
})();

// Tema claro fixo: elimina qualquer preferência antiga de modo escuro.
try{localStorage.removeItem('nuvii-theme')}catch{}
document.documentElement.removeAttribute('data-theme');

// Foto de perfil persistida localmente, com compressão e validação de tamanho/formato.
(function setupProfilePhoto(){
  const input=$('#profile-photo'),avatar=$('#profile-avatar'),remove=$('#remove-profile-photo');
  if(!input||!avatar) return;
  const KEY='nuvii-profile-photo-v1';
  const show=(data)=>{if(data){avatar.innerHTML=`<img src="${data}" alt="Foto de perfil">`;avatar.classList.add('has-photo');}else{avatar.textContent='☺';avatar.classList.remove('has-photo');}if(remove)remove.hidden=!data;};
  try{show(localStorage.getItem(KEY));}catch{show(null)}
  input.addEventListener('change',()=>{
    const file=input.files?.[0]; if(!file)return;
    if(!/^image\/(jpeg|png|webp)$/.test(file.type)){toast('Escolha uma imagem JPG, PNG ou WebP.');input.value='';return;}
    if(file.size>5*1024*1024){toast('A imagem deve ter no máximo 5 MB.');input.value='';return;}
    const reader=new FileReader();
    reader.onerror=()=>toast('Não foi possível ler a imagem selecionada.');
    reader.onload=()=>{
      const image=new Image();
      image.onerror=()=>toast('O arquivo selecionado não é uma imagem válida.');
      image.onload=()=>{
        const scale=Math.min(1,600/Math.max(image.width,image.height)),canvas=document.createElement('canvas');
        canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));
        const ctx=canvas.getContext('2d');ctx.drawImage(image,0,0,canvas.width,canvas.height);
        const compressed=canvas.toDataURL('image/jpeg',0.82);
        try{localStorage.setItem(KEY,compressed);show(compressed);toast('Foto salva neste navegador.');}
        catch{toast('Não foi possível salvar a foto. Tente uma imagem menor.');}
      }; image.src=reader.result;
    };reader.readAsDataURL(file);
  });
  remove?.addEventListener('click',()=>{localStorage.removeItem(KEY);show(null);input.value='';toast('Foto removida.');});
})();

// O botão de fechar conversa mantém aparência discreta, mas reconhecível.


/* Nuvii Emotion Controller — estado global compartilhado entre todas as abas. */
(() => {
  const companion = document.getElementById('nuvii-companion');
  if (!companion) return;
  const bubble = document.getElementById('nuvii-companion-bubble');
  const bubbleText = document.getElementById('nuvii-bubble-text');
  const floatingMascot = document.getElementById('nuvii-mascot-floating');
  const homeMascot = document.getElementById('nuvii-mascot');
  const trigger = document.getElementById('nuvii-companion-trigger');
  const BUBBLE_MS = 4000;
  const IDLE_MS = 60000;
  let bubbleTimer = null;
  let idleTimer = null;
  let transientTimer = null;
  let transientState = false;
  let lastMood = 'idle';
  let userIsChatting = false;
  let chatIdleTimer = null;

  const messages = {
    happyAdd: [
      'Boa! Mais uma tarefa organizada. ✨',
      'Ótimo começo! Uma coisa de cada vez. 💜',
      'Mais um passo para deixar seu dia leve!',
      'Adorei! Sua lista está ficando mais organizada. 🌟',
      'Tarefa adicionada! Você já começou a cuidar disso.'
    ],
    dance: [
      'Você conseguiu! Mais uma etapa concluída! 💜',
      'Uhuuul! Olha você avançando! ✨',
      'Tarefa concluída! Vamos comemorar essa conquista!',
      'Mandou muito bem! Seu esforço virou resultado. 🎉',
      'Mais uma conquista para a conta! Dance comigo! 💃'
    ],
    sad: [
      'Parece que há bastante coisa acumulada. Vamos escolher uma tarefa para começar, sem pressão?',
      'Respira. Não precisamos resolver tudo agora. Qual é o menor próximo passo?',
      'Tem muita coisa na lista, mas vamos por partes. Estou aqui com você. 💜',
      'Eu sei que essa lista pode parecer pesada. Vamos cuidar de uma coisinha por vez?',
      'Não precisa dar conta de tudo hoje. Vamos escolher só o próximo passo, juntos.'
    ],
    focused: [
      'Vamos manter o foco em uma etapa por vez. Você está avançando!',
      'Uma coisa de cada vez. Vamos seguir no seu ritmo.',
      'Vamos concentrar a energia no próximo passo, sem tentar fazer tudo ao mesmo tempo.',
      'Seu foco está em ação! Escolha uma tarefa e vamos até o próximo passo. 🎯',
      'Sem pressa e sem fazer tudo de uma vez: vamos continuar com atenção.'
    ],
    sleeping: [
      'Está tudo tranquilo por aqui. Vou descansar um pouquinho. 😴',
      'Tudo em dia ou um momento de pausa… vou tirar uma soneca. 💜',
      'Zzz… estarei aqui quando você precisar.',
      'Vou fechar os olhinhos por um instante. Chame quando quiser continuar. 💤',
      'Pausa ativada! Quando você voltar, a gente retoma juntinhos.'
    ],
    curious: [
      'Estou aqui! Me conta um pouco mais para eu te ajudar. 💜',
      'Hmm, quero entender melhor. O que está passando pela sua cabeça?',
      'Pode me contar. Vamos pensar nisso juntinhos.',
      'Opa, quero saber mais! Qual parte você quer resolver primeiro? 👀',
      'Estou prestando atenção. Me conta do seu jeito, sem pressa.'
    ],
    thinking: [
      'Deixa eu organizar as ideias para te responder melhor…',
      'Estou pensando em como podemos resolver isso por partes.',
      'Vamos encontrar um próximo passo possível.',
      'Hmm… estou juntando as peças para encontrar uma boa solução. 💭',
      'Vou pensar com calma e transformar isso em passos mais simples.'
    ],
    neutral: [
      'Estou por aqui, pronto para ajudar. 💜',
      'Vamos no seu ritmo.',
      'Pode contar comigo para organizar as ideias.',
      'Vamos deixar as coisas mais simples, um passo de cada vez.',
      'Estou aqui com você. O que seria útil fazer agora?'
    ],
    wake: [
      'Oi, voltei! O que vamos fazer agora? 💜',
      'Estou acordado e pronto para ajudar!',
      'Que bom ter você por aqui de novo!',
      'Opa, voltei à ativa! Vamos continuar de onde paramos? ✨',
      'Olá! Estou aqui para ajudar no próximo passo.'
    ]
  };
  const lastPhraseByMood = Object.create(null);
  function pick(list) {
    if (!Array.isArray(list) || !list.length) return '';
    const key = Object.keys(messages).find(k => messages[k] === list) || 'default';
    let phrase = list[Math.floor(Math.random() * list.length)];
    if (list.length > 1 && phrase === lastPhraseByMood[key]) {
      const alternatives = list.filter(item => item !== lastPhraseByMood[key]);
      phrase = alternatives[Math.floor(Math.random() * alternatives.length)];
    }
    lastPhraseByMood[key] = phrase;
    return phrase;
  }
  function getCurrentPage() {
    return document.body.dataset.currentPage ||
      document.querySelector('.page.active')?.id?.replace('page-','') || 'home';
  }
  function getTasksSnapshot() {
    try {
      if (typeof tasks !== 'undefined' && Array.isArray(tasks)) {
        const all = tasks;
        const unfinished = all.filter(t => !t.done);
        const inProgress = unfinished.filter(t =>
          Boolean(t.startedAt) || (Array.isArray(t.steps) && t.steps.some(s => s.done))
        );
        return { total: all.length, done: all.filter(t => t.done).length,
          pending: unfinished.length, inProgress: inProgress.length };
      }
    } catch {}
    return { total: 0, done: 0, pending: 0, inProgress: 0 };
  }
  function baseMood() {
    const s = getTasksSnapshot();
    if (s.total === 0 || s.done === s.total) return { state: 'resting', key: 'sleeping' };
    // Acolhimento tem prioridade quando há 5+ pendentes; foco vale para os demais casos.
    if (s.pending >= 5) return { state: 'sad', key: 'sad' };
    if (s.inProgress >= 3) return { state: 'focused', key: 'focused' };
    return { state: 'idle', key: 'neutral' };
  }
  function clearBubbleTimer() {
    if (bubbleTimer) window.clearTimeout(bubbleTimer);
    bubbleTimer = null;
  }
  function closeBubble() {
    clearBubbleTimer();
    bubble.classList.add('is-hidden');
  }
  function openBubble(message, duration = BUBBLE_MS) {
    bubbleText.textContent = message;
    bubble.classList.remove('is-hidden');
    clearBubbleTimer();
    if (duration > 0) bubbleTimer = window.setTimeout(closeBubble, duration);
  }
  function setState(state) {
    [floatingMascot, homeMascot].filter(Boolean).forEach(el => {
      el.dataset.state = state;
      el.setAttribute('aria-label', 'Nuvii: ' + ({
        idle:'tranquilo', happy:'feliz', dancing:'comemorando', sad:'acolhedor',
        focused:'concentrado', resting:'dormindo', curious:'curioso', thinking:'pensando'
      }[state] || state));
    });
    lastMood = state;
  }
  function applyBaseMood(showMessage = false) {
    if (transientState || userIsChatting) return;
    const mood = baseMood();
    setState(mood.state);
    if (showMessage) openBubble(pick(messages[mood.key]));
  }
  function showTransient(state, phraseList, after = 2600) {
    transientState = true;
    setState(state);
    openBubble(pick(phraseList));
    if (transientTimer) window.clearTimeout(transientTimer);
    transientTimer = window.setTimeout(() => {
      transientState = false;
      applyBaseMood(false);
    }, after);
  }
  function resetIdleTimer() {
    if (idleTimer) window.clearTimeout(idleTimer);
    idleTimer = window.setTimeout(() => {
      transientState = false;
      userIsChatting = false;
      setState('resting');
      openBubble(pick(messages.sleeping));
    }, IDLE_MS);
  }
  function noteInteraction() {
    const wasSleeping = lastMood === 'resting';
    if (wasSleeping) showTransient('curious', messages.wake, 1800);
    resetIdleTimer();
  }
  function endConversation() {
    userIsChatting = false;
    if (chatIdleTimer) window.clearTimeout(chatIdleTimer);
    chatIdleTimer = null;
    if (!transientState) applyBaseMood(false);
  }
  function thinking() {
    noteInteraction();
    userIsChatting = false;
    showTransient('thinking', messages.thinking, 900);
  }
  function taskAdded() {
    noteInteraction();
    showTransient('happy', messages.happyAdd, 2400);
  }
  window.NuviiEmotionController = { thinking, taskAdded, endConversation };
  trigger?.addEventListener('click', () => {
    const collapsed = companion.classList.toggle('collapsed');
    trigger.setAttribute('aria-expanded', String(!collapsed));
    noteInteraction();
  });
  document.getElementById('nuvii-bubble-close')?.addEventListener('click', closeBubble);

  // A navegação existente continua responsável por trocar as telas.
  document.querySelectorAll('[data-page]').forEach(button => {
    button.addEventListener('click', () => {
      noteInteraction();
      const page = button.dataset.page || 'home';
      const isHome = page === 'home';
      document.body.classList.remove('nuvii-transition-to-inner','nuvii-transition-to-home');
      document.body.classList.add(isHome ? 'nuvii-transition-to-home' : 'nuvii-transition-to-inner');
      document.body.classList.toggle('nuvii-show-companion', !isHome);
      window.clearTimeout(button._nuviiTransitionTimer);
      button._nuviiTransitionTimer = window.setTimeout(() => {
        document.body.classList.remove('nuvii-transition-to-inner','nuvii-transition-to-home');
      }, 560);
      if (!transientState && !userIsChatting) applyBaseMood(false);
    });
  });

  // Tarefa criada: felicidade curta; conclusão: dança.
  const taskForm = document.getElementById('task-form');
  taskForm?.addEventListener('submit', event => {
    const title = document.getElementById('task-title')?.value?.trim();
    if (!title) return;
    noteInteraction();
    showTransient('happy', messages.happyAdd, 2200);
  }, true);
  document.addEventListener('click', event => {
    const completeButton = event.target.closest('#detail-finish');
    if (!completeButton) return;
    const doneBefore = getTasksSnapshot().done;
    noteInteraction();
    window.setTimeout(() => {
      const doneAfter = getTasksSnapshot().done;
      if (doneAfter > doneBefore) showTransient('dancing', messages.dance, 3000);
      else applyBaseMood(false);
    }, 0);
  });
  document.addEventListener('change', event => {
    if (event.target.matches('[data-step]')) {
      noteInteraction();
      window.setTimeout(() => {
        const snap = getTasksSnapshot();
        if (snap.total > 0 && snap.done > 0 && snap.done === snap.total) showTransient('dancing', messages.dance, 3000);
        else applyBaseMood(false);
      }, 0);
    }
  });

  // Conversa: curioso enquanto o usuário digita e até 4s após cada mensagem/resposta.
  ['quick-form','ai-form'].forEach(id => {
    const form = document.getElementById(id);
    const input = form?.querySelector('input');
    input?.addEventListener('focus', () => {
      noteInteraction(); userIsChatting = true;
      setState('curious'); openBubble(pick(messages.curious));
      if (chatIdleTimer) window.clearTimeout(chatIdleTimer); chatIdleTimer = window.setTimeout(endConversation, BUBBLE_MS);
    });
    input?.addEventListener('input', () => {
      noteInteraction(); userIsChatting = true; setState('curious');
      if (chatIdleTimer) window.clearTimeout(chatIdleTimer); chatIdleTimer = window.setTimeout(endConversation, BUBBLE_MS);
    });
    form?.addEventListener('submit', () => {
      const value = input?.value?.trim();
      if (!value) return;
      noteInteraction(); userIsChatting = true;
      setState('curious'); openBubble(pick(messages.curious));
      if (chatIdleTimer) window.clearTimeout(chatIdleTimer); chatIdleTimer = window.setTimeout(endConversation, BUBBLE_MS);
    });
  });
  ['quick-messages','ai-messages'].forEach(id => {
    const node = document.getElementById(id);
    if (!node) return;
    new MutationObserver(records => {
      const userAdded = records.some(r => [...r.addedNodes].some(n => n.nodeType === 1 && (n.classList?.contains('user') || n.querySelector?.('.user'))));
      if (!userAdded) return;
      userIsChatting = true;
      setState('curious');
      openBubble(pick(messages.curious));
      if (transientTimer) window.clearTimeout(transientTimer);
      transientTimer = window.setTimeout(() => {
        userIsChatting = false;
        applyBaseMood(false);
      }, BUBBLE_MS);
      resetIdleTimer();
    }).observe(node, { childList: true });
  });
  document.addEventListener('pointerdown', event => {
    if (event.target.closest('input, textarea, button, select, [role="button"]')) noteInteraction();
  }, { passive: true });
  document.addEventListener('keydown', noteInteraction, { passive: true });

  // Conecta-se diretamente às funções reais do sistema de tarefas.
  // Os botões de conclusão usam stopPropagation, portanto eventos no document não bastam.
  try {
    if (typeof toggleTask === 'function' && !toggleTask.__nuviiEmotionWrapped) {
      const originalToggleTask = toggleTask;
      const wrappedToggleTask = function(id) {
        const before = getTasksSnapshot().done;
        const result = originalToggleTask.apply(this, arguments);
        const after = getTasksSnapshot().done;
        noteInteraction();
        if (after > before) showTransient('dancing', messages.dance, 3000);
        else applyBaseMood(false);
        return result;
      };
      wrappedToggleTask.__nuviiEmotionWrapped = true;
      toggleTask = wrappedToggleTask;
    }
  } catch {}
  try {
    if (typeof renderTasks === 'function' && !renderTasks.__nuviiEmotionWrapped) {
      const originalRenderTasks = renderTasks;
      const wrappedRenderTasks = function() {
        const result = originalRenderTasks.apply(this, arguments);
        persistTasks();
        window.setTimeout(() => {
          const s = getTasksSnapshot();
          const sig = [s.total,s.done,s.pending,s.inProgress].join(':');
          if (sig !== taskSignature) {
            taskSignature = sig;
            if (!transientState && !userIsChatting) applyBaseMood(false);
          }
        }, 0);
        return result;
      };
      wrappedRenderTasks.__nuviiEmotionWrapped = true;
      renderTasks = wrappedRenderTasks;
    }
  } catch {}

  // Observa alterações de tarefa e mantém o estado coerente em qualquer aba.
  let taskSignature = '';
  window.setInterval(() => {
    const s = getTasksSnapshot();
    const signature = [s.total,s.done,s.pending,s.inProgress].join(':');
    if (signature !== taskSignature) {
      const changed = taskSignature !== '';
      taskSignature = signature;
      if (changed && !transientState && !userIsChatting) applyBaseMood(false);
    }
  }, 900);
  const initialPage = getCurrentPage();
  document.body.classList.toggle('nuvii-show-companion', initialPage !== 'home');
  taskSignature = (() => { const s=getTasksSnapshot(); return [s.total,s.done,s.pending,s.inProgress].join(':'); })();
  persistTasks();
  setState(baseMood().state);
  openBubble(pick(messages[baseMood().key]));
  resetIdleTimer();
})();
