# Nuvii — responsividade alinhada ao projeto de referência

## Alterações
- Reaplicada a estratégia responsiva do projeto `iamigo_projeto_login_cores_demo`: breakpoint de 480px para smartphones e ajustes de altura para telas compactas.
- Ajustadas largura e centralização dos contêineres de autenticação para usar a viewport disponível.
- Corrigido o checkbox “Manter conectado”, que estava herdando estilos genéricos de inputs e aparecendo como um campo alto.
- Ajustados os campos de autenticação, margens seguras e quebra dos controles em telas estreitas.
- Mantida a estrutura HTML e os scripts existentes.

## Arquivos
- `index.html`
- `previas/tela-login.html`
- `previas/tela-cadastro.html`

## Execução
Extraia o ZIP e abra `index.html` no navegador. As fontes externas podem exigir internet.
