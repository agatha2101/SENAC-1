﻿from ui.utils import (
    exibir_cabecalho,
    exibir_barra_status,
    exibir_progresso
)
from data.data_manager import carregar_dados, salvar_dados
import core.tarefas as core_tarefas
from controllers.tarefa_controller import TarefaController
import core.ia_service as ia_service
import random


def criar_usuario_menu(dados: dict):
    exibir_cabecalho("BEM-VINDO(A)")

    nome = input(
        "Como você gostaria de ser chamado(a)? "
    ).strip()

    if not nome:
        input(
            "\nNão consegui identificar seu nome. "
            "Tente novamente. (ENTER)"
        )
        return

    if nome in dados:
        input(
            f"\nJá encontrei um cadastro com o nome "
            f"'{nome}'. Tente novamente para seguirmos! "
            "(ENTER)"
        )
        return

    print("\nMe conta uma coisa:")
    print(
        "Quando você precisa fazer algo, "
        "o que funciona melhor para você?"
    )
    print("1. Instruções curtas e sem enrolação")
    print(
        "2. Um guia mais detalhado, "
        "explicando cada etapa"
    )

    pref = input("Opção: ").strip()

    estilo = (
        "direto"
        if pref == "1"
        else "detalhado"
    )

    dados[nome] = {
        "preferencias": {
            "estilo_instrucao": estilo
        },
        "tarefas_diarias": [],
        "tarefas_educacionais": []
    }

    salvar_dados(dados)

    input(
        f"\nTudo certo, [{nome}]! "
        "Seu perfil foi criado. "
        "Pressione ENTER para continuar."
    )


def gerenciar_tarefas_menu(
    dados: dict,
    usuario: str,
    chave: str,
    titulo: str
):
    tarefa_controller = TarefaController()

    while True:
        exibir_cabecalho(titulo)

        tarefas = dados[usuario][chave]

        exibir_progresso(tarefas)

        if not tarefas:
            print("""
            ╔════════════════════════════════════╗
            ║          🎉 TUDO EM DIA!           ║
            ╠════════════════════════════════════╣
            ║ Nenhuma tarefa pendente por aqui. ║
            ╚════════════════════════════════════╝
            """)

        else:
            print("\n📋 SUAS ATIVIDADES:\n")

            for idx, tarefa in enumerate(
                tarefas,
                1
            ):
                status = (
                    "✅"
                    if tarefa["concluida"]
                    else "⏳"
                )

                print(
                    f"{idx}. "
                    f"{status} "
                    f"{tarefa['titulo']}"
                )

                for passo in tarefa.get(
                    "passos",
                    []
                ):
                    print(
                        f"    └─ 📌 "
                        f"{passo['texto']}"
                    )

                print()

        print("\n" + "-" * 30)

        print("""
        ╔════════════════════════════════════════════════════════════╗
        ║ 1. 📝 Adicionar                                           ║
        ║ 2. 📂 Abrir tarefa                                        ║
        ║ 3. 🤖 IA                                                  ║
        ║ 4. 🔙 Voltar                                               ║
        ╚════════════════════════════════════════════════════════════╝
        """)

        opcao = input(
            "\nEscolha uma opção: "
        ).strip()

        if opcao == "1":
            print(
                "\n🤖 Certo! "
                "Vamos criar uma nova atividade."
            )

            t_nome = input(
                "➜ O que você precisa fazer hoje? "
            ).strip()

            if t_nome:
                resposta = (
                    tarefa_controller.criar_tarefa(
                        usuario_nome=usuario,
                        tipo=chave,
                        titulo=t_nome
                    )
                )

                if not resposta["sucesso"]:
                    print(
                        f"\n❌ "
                        f"{resposta['mensagem']}"
                    )

                    input(
                        "\nPressione ENTER "
                        "para continuar..."
                    )
                    continue

                dados_atualizados = carregar_dados()

                dados.clear()
                dados.update(
                    dados_atualizados
                )

                mensagens = [
                    "🌟 Excelente! Já anotei isso.",
                    "🚀 Um passo de cada vez!",
                    "📌 Atividade adicionada com sucesso.",
                    "💙 Pode deixar, está tudo anotado.",
                    "🎯 Agora ficou mais fácil lembrar."
                ]

                print(
                    f"\n{random.choice(mensagens)}"
                )
                print(
                    f"📌 {t_nome}"
                )

                input(
                    "\nPressione ENTER "
                    "para continuar..."
                )

        elif opcao == "2":
            if not tarefas:
                input(
                    "\nNão há tarefas para abrir. "
                    "Pressione ENTER..."
                )
                continue

            try:
                indice = (
                    int(
                        input(
                            "\nQual tarefa deseja abrir? "
                        )
                    )
                    - 1
                )

                if 0 <= indice < len(tarefas):
                    abrir_tarefa_menu(
                        dados,
                        usuario,
                        chave,
                        indice
                    )

                else:
                    input(
                        "\nTarefa não encontrada. "
                        "Pressione ENTER..."
                    )

            except ValueError:
                print(
                    "\nNúmero inválido."
                )

                input(
                    "\nPressione ENTER..."
                )

        elif opcao == "3":
            painel_ia_menu(
                dados,
                usuario
            )

        elif opcao == "4":
            break


def painel_ia_menu(
    dados: dict,
    usuario: str
):
    exibir_cabecalho(
        "🤖 IAMIGO"
    )

    print("""
        ╔════════════════════════════════════╗
        ║        CONVERSA COM IAMIGO         ║
        ╠════════════════════════════════════╣
        ║ Pode me perguntar qualquer coisa! ║
        ╚════════════════════════════════════╝
    """)

    print(
        "Peça ajuda para simplificar enunciados, "
        "organizar rotinas ou tirar dúvidas."
    )
    print(
        "Digite 'sair' para retornar.\n"
    )

    estilo = (
        dados[usuario]
        ["preferencias"]
        ["estilo_instrucao"]
    )

    while True:
        pergunta = input(
            "\nVocê: "
        ).strip()

        if pergunta.lower() == "sair":
            print(
                "\n👋 Até a próxima!"
            )
            break

        if not pergunta:
            continue

        frases = [
            "🤔 Estou pensando...",
            "🧠 Analisando sua pergunta...",
            "📚 Organizando a resposta...",
            "💡 Tenho uma ideia!",
            "🎯 Vamos simplificar isso..."
        ]

        print(
            f"\n{random.choice(frases)}"
        )

        respostas = (
            ia_service.obter_resposta_ia(
                pergunta,
                estilo
            )
        )

        print(
            "\n🤖 IAmigo:"
        )

        for linha in respostas:
            print(
                f"- {linha}"
            )

        print(
            "\n" + "=" * 36
        )


def painel_principal_menu(
    dados: dict,
    usuario: str
):
    while True:
        exibir_cabecalho(
            "PAINEL DO USUÁRIO:"
        )

        exibir_barra_status(
            usuario
        )

        print("""
        ╔════════════════════════════════════╗
        ║      COMO POSSO TE AJUDAR?         ║
        ╠════════════════════════════════════╣
        ║ 1. 📝 Organizar minhas tarefas     ║
        ║ 2. 📚 Planejar meus estudos        ║
        ║ 3. 🤖 Conversar com o IAmigo       ║
        ║ 4. 👋 Encerrar por agora           ║
        ╚════════════════════════════════════╝
        """)

        opcao = input(
            "\nEscolha: "
        ).strip()

        if opcao == "1":
            print(
                "\n🤖 Vamos colocar "
                "suas tarefas em ordem!"
            )

            input(
                "\nPressione ENTER "
                "para continuar..."
            )

            gerenciar_tarefas_menu(
                dados,
                usuario,
                "tarefas_diarias",
                "ROTINA DIÁRIA"
            )

        elif opcao == "2":
            print(
                "\n🤖 Ótimo! "
                "Vamos focar nos estudos."
            )

            input(
                "\nPressione ENTER "
                "para continuar..."
            )

            gerenciar_tarefas_menu(
                dados,
                usuario,
                "tarefas_educacionais",
                "ESTUDOS E EDUCAÇÃO"
            )

        elif opcao == "3":
            print(
                "\n🤖 Estou pronto "
                "para conversar com você!"
            )

            input(
                "\nPressione ENTER "
                "para continuar..."
            )

            painel_ia_menu(
                dados,
                usuario
            )

        elif opcao == "4":
            print(
                "\n🤖 Foi muito bom "
                "conversar com você hoje."
            )
            print(
                "👋 Até a próxima!"
            )
            break


def abrir_tarefa_menu(
    dados,
    usuario,
    chave,
    indice_tarefa
):
    while True:
        tarefa = (
            dados[usuario]
            [chave]
            [indice_tarefa]
        )

        exibir_cabecalho(
            "TAREFA"
        )

        print(
            f"\n📁 {tarefa['titulo']}\n"
        )

        print(
            "Subtarefas:\n"
        )

        subtarefas = tarefa.get(
            "subtarefas",
            []
        )

        if not subtarefas:
            print(
                "Nenhuma subtarefa criada."
            )

        else:
            for i, sub in enumerate(
                subtarefas,
                1
            ):
                status = (
                    "☑"
                    if sub["concluida"]
                    else "☐"
                )

                print(
                    f"{i}. "
                    f"{status} "
                    f"{sub['titulo']}"
                )

        print(
            "\n" + "-" * 35
        )

        print(
            "1 - Nova subtarefa"
        )
        print(
            "2 - Marcar subtarefa"
        )
        print(
            "3 - Excluir subtarefa"
        )
        print(
            "4 - Voltar"
        )

        opcao = input(
            "\nEscolha: "
        ).strip()

        if opcao == "4":
            break

        if opcao == "1":
            titulo = input(
                "\nNome da subtarefa: "
            ).strip()

            if titulo:
                core_tarefas.adicionar_subtarefa(
                    dados,
                    usuario,
                    chave,
                    indice_tarefa,
                    titulo
                )

                print(
                    "\n✅ Subtarefa adicionada!"
                )

                input(
                    "\nPressione ENTER..."
                )