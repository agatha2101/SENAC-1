import logging
import json
import random
import time

logging.basicConfig(
    filename="iamigo.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

from urllib import request, error

from data.data_manager import carregar_dados
from ui.menus import criar_usuario_menu, painel_principal_menu


def exibir_logo():
    print("""
    ╔══════════════════════════════════════════════════╗
    ║                                                  ║
    ║   ██╗ █████╗ ███╗   ███╗██╗ ██████╗  ██████╗   ║
    ║   ██║██╔══██╗████╗ ████║██║██╔════╝ ██╔═══██╗  ║
    ║   ██║███████║██╔████╔██║██║██║  ███╗██║   ██║  ║
    ║   ██║██╔══██║██║╚██╔╝██║██║██║   ██║██║   ██║  ║
    ║   ██║██║  ██║██║ ╚═╝ ██║██║╚██████╔╝╚██████╔╝  ║
    ║   ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝ ╚═════╝  ╚═════╝   ║
    ║                                                  ║
    ║   Seu amigo para organizar tarefas e estudos    ║
    ║                                                  ║
    ║       Desenvolvido para auxiliar pessoas        ║
    ║            com dificuldades de foco             ║
    ║                                                  ║
    ╚══════════════════════════════════════════════════╝
    """)


def exibir_frase():
    frases = [
        "😊 Que bom te ver por aqui!",
        "🚀 Vamos organizar o dia juntos?",
        "📚 Um passo de cada vez.",
        "✨ Pequenos avanços também são conquistas.",
        "🎯 Vamos focar no que importa hoje.",
        "🌟 Você está indo muito bem!",
        "🤖 Estou pronto para ajudar.",
        "💡 Toda tarefa começa com um primeiro passo.",
        "📝 Vamos colocar as ideias em ordem?",
        "😄 Pronto para mais um dia produtivo?"
    ]

    print(f"\n{random.choice(frases)}\n")


def tela_carregamento():
    etapas = [
        "█░░░░░░░░░░ 10%",
        "███░░░░░░░░ 30%",
        "██████░░░░░ 60%",
        "███████████ 100%"
    ]

    print("""
    ╔══════════════════════════════════════╗
    ║          INICIANDO IAMIGO            ║
    ╚══════════════════════════════════════╝
    """)

    for etapa in etapas:
        print(etapa)
        time.sleep(0.4)

    print("\n✅ Sistema pronto!\n")
    time.sleep(1)

def fazer_login_api(nome, senha):
    url = "http://127.0.0.1:8000/usuarios/login"

    body = json.dumps({
        "nome": nome,
        "senha": senha
    }).encode("utf-8")

    requisicao = request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        method="POST"
    )

    try:
        with request.urlopen(
            requisicao,
            timeout=5
        ) as resposta:
            return json.loads(
                resposta.read().decode("utf-8")
            )

    except error.HTTPError as erro_http:
        logging.error(
            "Erro HTTP no login: status=%s",
            erro_http.code
        )

        try:
            dados_erro = json.loads(
                erro_http.read().decode("utf-8")
            )

            mensagem = dados_erro.get(
                "detail",
                "Não foi possível realizar o login."
            )

        except Exception as erro:
            logging.error(
                "Erro ao interpretar resposta do login: %s",
                erro
            )

            mensagem = "Não foi possível realizar o login."

        return {
            "sucesso": False,
            "status": erro_http.code,
            "mensagem": mensagem
        }

    except error.URLError as erro:
        logging.error(
            "Falha de conexão com a API no login: %s",
            erro
        )

        return {
            "sucesso": False,
            "status": 0,
            "mensagem": "Não foi possível conectar à API."
        }


def montar_headers_autenticados(token):
    return {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}"
    }


def buscar_usuario_logado(token):
    url = "http://127.0.0.1:8000/usuarios/me"

    headers = montar_headers_autenticados(
        token
    )

    print(
        "\n🔎 Authorization enviado:"
        f"\nBearer {token[:12]}...{token[-8:]}"
    )

    requisicao = request.Request(
        url,
        headers=headers,
        method="GET"
    )

    try:
        with request.urlopen(
            requisicao,
            timeout=5
        ) as resposta:

            dados = json.loads(
                resposta.read().decode("utf-8")
            )

            return {
                "status": resposta.status,
                "dados": dados
            }

    except error.HTTPError as erro_http:
        try:
            dados_erro = json.loads(
                erro_http.read().decode("utf-8")
            )

            mensagem = dados_erro.get(
                "detail",
                "Erro na requisição."
            )

        except Exception:
            mensagem = "Erro na requisição."

        return {
            "status": erro_http.code,
            "mensagem": mensagem
        }

    except error.URLError:
        return {
            "status": 0,
            "mensagem": "Não foi possível conectar à API."
        }


def executar_sistema():
    while True:
        dados = carregar_dados()

        exibir_logo()
        print("Olá! 👋 Eu sou o IAmigo.")
        exibir_frase()

        print("""
        ╔════════════════════════════════════╗
        ║         O QUE VAMOS FAZER?         ║
        ╠════════════════════════════════════╣
        ║ 1. Continuar com meu perfil        ║
        ║ 2. Criar um novo perfil            ║
        ║ 3. Encerrar por agora              ║
        ╚════════════════════════════════════╝
        """)

        opcao = input(
            "\nEscolha uma opção: "
        ).strip()

        if opcao == "1":
            if not dados:
                input(
                    "\nNenhum perfil salvo. "
                    "Crie um primeiro! (ENTER)"
                )
                continue

            print(
                "        ╔════════════════════════════════════╗"
            )
            print(
                "        ║         PERFIS ENCONTRADOS         ║"
            )
            print(
                "        ╠════════════════════════════════════╣"
            )

            for usuario in dados:
                nome_formatado = usuario.ljust(32)

                print(
                    f"        ║ 👤 {nome_formatado}║"
                )

            print(
                "        ╚════════════════════════════════════╝"
            )

            nome = input(
                "\n✨ Qual perfil deseja acessar? "
            ).strip()

            if nome not in dados:
                input(
                    "\n🤖🔍 Opa! Não encontrei esse perfil "
                    "na minha lista.\n"
                    "Pressione ENTER para tentar novamente."
                )
                continue

            senha = input(
                "🔐 Senha: "
            )

            print(
                "\n⏳ Entrando... Aguarde."
            )

            resposta = fazer_login_api(
                nome,
                senha
            )

            if not resposta.get("sucesso"):
                print(
                    "\n❌ Não foi possível entrar."
                )

                input(
                    f"{resposta.get('mensagem')}\n"
                    "Pressione ENTER para continuar..."
                )
                continue

            token = resposta["access_token"]

            print(
                "\n✅ Login realizado com sucesso!"
            )

            print(
                "🔑 Token recebido no login:"
                f"\n{token[:12]}...{token[-8:]}"
            )

            print(
                "\n⏳ Carregando seus dados..."
            )

            usuario_logado = buscar_usuario_logado(
                token
            )

            if usuario_logado["status"] == 401:
                token = None

                input(
                    "\n🔒 Sua sessão não é válida "
                    "ou expirou.\n"
                    "Faça login novamente.\n"
                    "Pressione ENTER..."
                )
                continue

            if usuario_logado["status"] == 403:
                input(
                    "\n⛔ Você está autenticado, "
                    "mas não possui permissão "
                    "para acessar este recurso.\n"
                    "Pressione ENTER..."
                )
                continue

            if usuario_logado["status"] != 200:
                input(
                    f"\n❌ "
                    f"{usuario_logado.get('mensagem', 'Erro ao acessar a API.')}\n"
                    "Pressione ENTER..."
                )
                continue

            print(
                "\n✅ Dados carregados com sucesso!"
            )

            print(
                "🔐 Token validado pela rota protegida!"
            )

            painel_principal_menu(
                dados,
                nome
            )

            # Logout: token existe apenas durante a sessão.
            token = None

        elif opcao == "2":
            criar_usuario_menu(
                dados
            )

        elif opcao == "3":
            print(
                "\nAté logo 👋, não esqueça de realizar "
                "suas tarefas diárias 📝!"
            )
            break


if __name__ == "__main__":
    tela_carregamento()
    executar_sistema()