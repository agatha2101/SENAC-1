﻿from repositories.usuario_repository import UsuarioRepository
from services.tarefa_service import TarefaService


class TarefaController:
    def __init__(
        self,
        service=None,
        usuario_repository=None
    ):
        self.service = service or TarefaService()
        self.usuario_repository = (
            usuario_repository or UsuarioRepository()
        )

    def listar_tarefas(
        self,
        usuario_autenticado,
        usuario_id=None
    ):
        try:
            tarefas = self.service.listar_tarefas_autorizado(
                usuario_autenticado,
                usuario_id=usuario_id
            )

            return {
                "sucesso": True,
                "dados": [
                    {
                        "id": tarefa.id,
                        "usuario_id": tarefa.usuario_id,
                        "tipo": tarefa.tipo,
                        "titulo": tarefa.titulo,
                        "descricao": tarefa.descricao,
                        "prioridade": tarefa.prioridade,
                        "prazo": tarefa.prazo,
                        "concluida": tarefa.concluida,
                        "criado_em": tarefa.criado_em
                    }
                    for tarefa in tarefas
                ]
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO LISTAR TAREFAS:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível listar as tarefas."
            }

    def buscar_tarefa(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        try:
            tarefa = self.service.buscar_tarefa_autorizado(
                usuario_autenticado,
                tarefa_id
            )

            return {
                "sucesso": True,
                "dados": {
                    "id": tarefa.id,
                    "usuario_id": tarefa.usuario_id,
                    "tipo": tarefa.tipo,
                    "titulo": tarefa.titulo,
                    "descricao": tarefa.descricao,
                    "prioridade": tarefa.prioridade,
                    "prazo": tarefa.prazo,
                    "concluida": tarefa.concluida,
                    "criado_em": tarefa.criado_em
                }
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO BUSCAR TAREFA:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível buscar a tarefa."
            }

    def criar_tarefa(
        self,
        usuario_autenticado,
        usuario_nome,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None
    ):
        try:
            usuario = (
                self.usuario_repository.buscar_por_nome(
                    usuario_nome
                )
            )

            if usuario is None:
                raise ValueError(
                    "Usuário não encontrado."
                )

            tarefa = self.service.criar_tarefa_autorizado(
                usuario_autenticado,
                usuario_id=usuario.id,
                tipo=tipo,
                titulo=titulo,
                descricao=descricao,
                prioridade=prioridade,
                prazo=prazo
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": (
                    f"Atividade {tarefa.titulo} adicionada."
                )
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO CRIAR TAREFA:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível adicionar a atividade."
                )
            }

    def atualizar_status(
        self,
        usuario_autenticado,
        tarefa_id,
        concluida
    ):
        try:
            tarefa = self.service.atualizar_status_autorizado(
                usuario_autenticado,
                tarefa_id,
                concluida
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": "Status da tarefa atualizado.",
                "dados": {
                    "id": tarefa.id,
                    "concluida": tarefa.concluida
                }
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO ATUALIZAR TAREFA:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível atualizar a tarefa."
                )
            }

    def listar_passos(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        try:
            passos = self.service.listar_passos_autorizado(
                usuario_autenticado,
                tarefa_id
            )

            return {
                "sucesso": True,
                "dados": passos
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO LISTAR PASSOS:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível listar os passos."
                )
            }

    def atualizar_status_passo(
        self,
        usuario_autenticado,
        tarefa_id,
        passo_id,
        concluido
    ):
        try:
            passo = (
                self.service.atualizar_status_passo_autorizado(
                    usuario_autenticado,
                    tarefa_id,
                    passo_id,
                    concluido
                )
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": "Status do passo atualizado.",
                "dados": passo
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO ATUALIZAR PASSO:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível atualizar o passo."
                )
            }

    def gerar_passos(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        try:
            passos = self.service.gerar_passos_autorizado(
                usuario_autenticado,
                tarefa_id
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": "Passos gerados com sucesso.",
                "dados": passos
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO GERAR PASSOS:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível gerar os passos."
                )
            }

    def excluir_tarefa(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        try:
            self.service.excluir_tarefa_autorizado(
                usuario_autenticado,
                tarefa_id
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": "Tarefa excluída com sucesso."
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO EXCLUIR TAREFA:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível excluir a tarefa."
                )
            }