from services.usuario_service import UsuarioService


class UsuarioController:
    def __init__(self, service=None):
        self.service = service or UsuarioService()
    def listar_perfis(
        self,
        usuario_autenticado
    ):
        try:
            usuarios = self.service.listar_usuarios_autorizado(
                usuario_autenticado
            )

            return {
                "sucesso": True,
                "dados": [
                    {
                        "id": usuario.id,
                        "nome": usuario.nome,
                        "estilo_instrucao": usuario.estilo_instrucao
                    }
                    for usuario in usuarios
                ]
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO LISTAR USUÁRIOS:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível listar os usuários."
            }
    
    def buscar_perfil(
        self,
        usuario_autenticado,
        usuario_id
    ):
        try:
            usuario = self.service.buscar_usuario_autorizado(
                usuario_autenticado,
                usuario_id
            )

            return {
                "sucesso": True,
                "dados": {
                    "id": usuario.id,
                    "nome": usuario.nome,
                    "estilo_instrucao": usuario.estilo_instrucao
                }
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO BUSCAR USUÁRIO:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível buscar o usuário."
            }
        
    def criar_perfil(
        self,
        nome,
        senha,
        estilo_instrucao
    ):
        try:
            usuario = self.service.criar_usuario(
                nome,
                senha,
                estilo_instrucao
            )
            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "mensagem": f"Perfil {usuario.nome} criado."
            }
        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }
        except Exception:
            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível concluir a operação."
            }

    def atualizar_perfil(
        self,
        usuario_autenticado,
        usuario_id,
        nome,
        estilo_instrucao,
        senha=None
    ):
        try:
            usuario = self.service.atualizar_usuario_autorizado(
                usuario_autenticado,
                usuario_id,
                nome,
                estilo_instrucao,
                senha
            )

            return {
                "sucesso": True,
                "mensagem": "Perfil atualizado com sucesso.",
                "dados": {
                    "id": usuario.id,
                    "nome": usuario.nome,
                    "estilo_instrucao": usuario.estilo_instrucao
                }
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except LookupError as erro:
            return {
                "sucesso": False,
                "tipo": "NAO_ENCONTRADO",
                "mensagem": str(erro)
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print("ERRO AO ATUALIZAR USUÁRIO:", erro)

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível atualizar o usuário."
            }
           

    def excluir_perfil(
        self,
        usuario_autenticado,
        usuario_id
    ):
        try:
            self.service.excluir_usuario_autorizado(
                usuario_autenticado,
                usuario_id
            )

            return {
                "sucesso": True,
                "mensagem": "Perfil excluído com sucesso."
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "SEM_PERMISSAO",
                "mensagem": str(erro)
            }

        except LookupError as erro:
            return {
                "sucesso": False,
                "tipo": "NAO_ENCONTRADO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO EXCLUIR USUÁRIO:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível excluir o usuário."
            }
        
    def login(self, nome, senha):
        try:
            usuario = self.service.autenticar(
                nome,
                senha
            )

            token = self.service.gerar_token_acesso(
                usuario
            )

            return {
                "sucesso": True,
                "mensagem": "Login realizado com sucesso.",
                "access_token": token,
                "token_type": "bearer",
                "dados": {
                    "id": usuario.id,
                    "nome": usuario.nome,
                    "estilo_instrucao": usuario.estilo_instrucao
                }
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "CREDENCIAIS_INVALIDAS",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO REALIZAR LOGIN:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível realizar o login."
            }

    def autenticar_token(self, authorization):
        try:
            usuario = self.service.validar_token_acesso(
                authorization
            )

            return {
                "sucesso": True,
                "usuario": usuario
            }

        except PermissionError as erro:
            return {
                "sucesso": False,
                "tipo": "NAO_AUTENTICADO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO AO VALIDAR TOKEN:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": "Não foi possível validar o acesso."
            }