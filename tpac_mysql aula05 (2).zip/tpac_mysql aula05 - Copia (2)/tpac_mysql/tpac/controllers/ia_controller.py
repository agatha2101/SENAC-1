from services.ia_service import IaService


class IaController:
    def __init__(self, service=None):
        self.service = service or IaService()

    def perguntar(
        self,
        usuario_id,
        pergunta
    ):
        try:
            resposta = self.service.perguntar(
                usuario_id,
                pergunta
            )

            return {
                "sucesso": True,
                "tipo": "SUCESSO",
                "dados": resposta
            }

        except ValueError as erro:
            return {
                "sucesso": False,
                "tipo": "REGRA_NEGOCIO",
                "mensagem": str(erro)
            }

        except Exception as erro:
            print(
                "ERRO NO ASSISTENTE IA:",
                erro
            )

            return {
                "sucesso": False,
                "tipo": "FALHA_TECNICA",
                "mensagem": (
                    "Não foi possível utilizar o assistente."
                )
            }