from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from controllers.usuario_controller import UsuarioController

router = APIRouter(
    prefix="/usuarios",
    tags=["usuarios"]
)

controller = UsuarioController()

bearer_scheme = HTTPBearer(
    auto_error=False
)


class NovoUsuario(BaseModel):
    nome: str
    senha: str
    estilo_instrucao: str = "direto"

class AtualizarUsuario(BaseModel):
    nome: str
    estilo_instrucao: str
    senha: str | None = None

class LoginUsuario(BaseModel):
    nome: str
    senha: str


@router.get("")
def listar_usuarios(
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    resposta = controller.listar_perfis(
        autenticacao["usuario"]
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta

@router.get("/me")
def usuario_autenticado(
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    usuario = autenticacao["usuario"]

    return {
        "id": usuario.id,
        "nome": usuario.nome,
        "estilo_instrucao": usuario.estilo_instrucao
    }

@router.get("/{usuario_id}")
def buscar_usuario(
    usuario_id: int,
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    resposta = controller.buscar_perfil(
        autenticacao["usuario"],
        usuario_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta

@router.put("/{usuario_id}")
def atualizar_usuario(
    usuario_id: int,
    dados: AtualizarUsuario,
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    resposta = controller.atualizar_perfil(
        autenticacao["usuario"],
        usuario_id,
        dados.nome,
        dados.estilo_instrucao,
        dados.senha
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "NAO_ENCONTRADO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=422,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta

@router.post("", status_code=status.HTTP_201_CREATED)
def criar_usuario(dados: NovoUsuario):
    resposta = controller.criar_perfil(
        dados.nome,
        dados.senha,
        dados.estilo_instrucao
    )

    if not resposta["sucesso"]:
        raise HTTPException(
            status_code=422,
            detail=resposta["mensagem"]
        )

    return resposta

@router.delete("/{usuario_id}")
def excluir_usuario(
    usuario_id: int,
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    resposta = controller.excluir_perfil(
        autenticacao["usuario"],
        usuario_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "NAO_ENCONTRADO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta

@router.post("/login")
def login_usuario(
    dados: LoginUsuario
):
    resposta = controller.login(
        dados.nome,
        dados.senha
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "CREDENCIAIS_INVALIDAS":
            raise HTTPException(
                status_code=401,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta