from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from controllers.ia_controller import IaController


router = APIRouter(
    prefix="/ia",
    tags=["ia"]
)

controller = IaController()


class PerguntaIA(BaseModel):
    usuario_id: int
    pergunta: str


@router.post("/perguntar")
def perguntar_ia(
    dados: PerguntaIA
):
    resposta = controller.perguntar(
        dados.usuario_id,
        dados.pergunta
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=422,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta