from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status
)
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBearer
)
from pydantic import BaseModel

from controllers.tarefa_controller import TarefaController
from controllers.usuario_controller import UsuarioController


router = APIRouter(
    prefix="/tarefas",
    tags=["tarefas"]
)

controller = TarefaController()
usuario_controller = UsuarioController()

bearer_scheme = HTTPBearer(
    auto_error=False
)


class NovaTarefa(BaseModel):
    usuario_nome: str
    tipo: str
    titulo: str
    descricao: str | None = None
    prioridade: str = "media"
    prazo: str | None = None


class StatusTarefa(BaseModel):
    concluida: bool


def obter_usuario_autenticado(
    credenciais: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    )
):
    authorization = None

    if credenciais is not None:
        authorization = (
            f"Bearer {credenciais.credentials}"
        )

    autenticacao = usuario_controller.autenticar_token(
        authorization
    )

    if not autenticacao["sucesso"]:
        if autenticacao["tipo"] == "NAO_AUTENTICADO":
            raise HTTPException(
                status_code=401,
                detail=autenticacao["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=autenticacao["mensagem"]
        )

    return autenticacao["usuario"]


@router.get("")
def listar_tarefas(
    usuario_id: int | None = None,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.listar_tarefas(
        usuario_autenticado,
        usuario_id=usuario_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.get("/{tarefa_id}")
def buscar_tarefa(
    tarefa_id: int,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.buscar_tarefa(
        usuario_autenticado,
        tarefa_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.get("/{tarefa_id}/passos")
def listar_passos_tarefa(
    tarefa_id: int,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.listar_passos(
        usuario_autenticado,
        tarefa_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.post(
    "",
    status_code=status.HTTP_201_CREATED
)
def criar_tarefa(
    dados: NovaTarefa,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.criar_tarefa(
        usuario_autenticado,
        usuario_nome=dados.usuario_nome,
        tipo=dados.tipo,
        titulo=dados.titulo,
        descricao=dados.descricao,
        prioridade=dados.prioridade,
        prazo=dados.prazo
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=422,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.patch("/{tarefa_id}/status")
def atualizar_status_tarefa(
    tarefa_id: int,
    dados: StatusTarefa,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.atualizar_status(
        usuario_autenticado,
        tarefa_id,
        dados.concluida
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.patch(
    "/{tarefa_id}/passos/{passo_id}/status"
)
def atualizar_status_passo(
    tarefa_id: int,
    passo_id: int,
    dados: StatusTarefa,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.atualizar_status_passo(
        usuario_autenticado,
        tarefa_id,
        passo_id,
        dados.concluida
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.post(
    "/{tarefa_id}/passos/gerar"
)
def gerar_passos_tarefa_api(
    tarefa_id: int,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.gerar_passos(
        usuario_autenticado,
        tarefa_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=422,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta


@router.delete("/{tarefa_id}")
def excluir_tarefa(
    tarefa_id: int,
    usuario_autenticado=Depends(
        obter_usuario_autenticado
    )
):
    resposta = controller.excluir_tarefa(
        usuario_autenticado,
        tarefa_id
    )

    if not resposta["sucesso"]:
        if resposta["tipo"] == "SEM_PERMISSAO":
            raise HTTPException(
                status_code=403,
                detail=resposta["mensagem"]
            )

        if resposta["tipo"] == "REGRA_NEGOCIO":
            raise HTTPException(
                status_code=404,
                detail=resposta["mensagem"]
            )

        raise HTTPException(
            status_code=500,
            detail=resposta["mensagem"]
        )

    return resposta