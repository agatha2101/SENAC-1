from sqlalchemy import select

from config.database import SessionLocal
from models.usuario import Usuario


class UsuarioRepository:
    def listar(self):
        with SessionLocal() as session:
            comando = select(Usuario).order_by(Usuario.nome)
            return list(session.scalars(comando))

    def buscar_por_nome(self, nome):
        with SessionLocal() as session:
            comando = select(Usuario).where(Usuario.nome == nome)
            return session.scalar(comando)
    
    def buscar_por_id(self, usuario_id):
        with SessionLocal() as session:
            return session.get(
                Usuario,
                usuario_id
            )
    
    def atualizar(
        self,
        usuario_id,
        nome,
        estilo_instrucao,
        senha_hash=None
    ):
        with SessionLocal() as session:
            usuario = session.get(
                Usuario,
                usuario_id
            )

            if usuario is None:
                return None

            usuario.nome = nome
            usuario.estilo_instrucao = estilo_instrucao

            if senha_hash is not None:
                usuario.senha_hash = senha_hash

            session.commit()
            session.refresh(usuario)

            return usuario
        
    def criar(
        self,
        nome,
        senha_hash,
        estilo_instrucao
    ):
        with SessionLocal() as session:
            usuario = Usuario(
                nome=nome,
                senha_hash=senha_hash,
                estilo_instrucao=estilo_instrucao
            )

            session.add(usuario)
            session.commit()
            session.refresh(usuario)

            return usuario
    
    def excluir(self, usuario_id):
        with SessionLocal() as session:
            usuario = session.get(
                Usuario,
                usuario_id
            )

            if usuario is None:
                return False

            session.delete(usuario)
            session.commit()

            return True

