﻿from sqlalchemy import select, text

from config.database import SessionLocal
from models.tarefa import Tarefa


class TarefaRepository:
    def listar(self):
        with SessionLocal() as session:
            comando = select(Tarefa).order_by(
                Tarefa.id
            )
            return list(session.scalars(comando))

    def listar_por_usuario(
        self,
        usuario_id,
        tipo=None
    ):
        with SessionLocal() as session:
            comando = select(Tarefa).where(
                Tarefa.usuario_id == usuario_id
            )

            if tipo is not None:
                comando = comando.where(
                    Tarefa.tipo == tipo
                )

            comando = comando.order_by(Tarefa.id)
            return list(session.scalars(comando))

    def atualizar_status_passo(
        self,
        tarefa_id,
        passo_id,
        concluido
    ):
        with SessionLocal() as session:
            comando = text("""
                UPDATE passos
                SET concluido = :concluido
                WHERE id = :passo_id
                AND tarefa_id = :tarefa_id
            """)

        resultado = session.execute(
            comando,
            {
                "concluido": concluido,
                "passo_id": passo_id,
                "tarefa_id": tarefa_id
            }
        )

        if resultado.rowcount == 0:
            session.rollback()
            return None

        session.commit()

        comando_busca = text("""
            SELECT
                id,
                tarefa_id,
                texto,
                concluido,
                ordem
            FROM passos
            WHERE id = :passo_id
        """)

        passo = session.execute(
            comando_busca,
            {"passo_id": passo_id}
        ).mappings().first()

        return dict(passo)

    def buscar_por_id(self, tarefa_id):
        with SessionLocal() as session:
            return session.get(
                Tarefa,
                tarefa_id
            )

    def listar_passos(self, tarefa_id):
        with SessionLocal() as session:
            comando = text("""
                SELECT
                    id,
                    tarefa_id,
                    texto,
                    concluido,
                    ordem
                FROM passos
                WHERE tarefa_id = :tarefa_id
                ORDER BY ordem, id
            """)

            resultado = session.execute(
                comando,
                {"tarefa_id": tarefa_id}
            ).mappings().all()

            return [
                dict(passo)
                for passo in resultado
            ]
        
    def salvar_passos(
        self,
        tarefa_id,
        passos
    ):
        with SessionLocal() as session:
            session.execute(
                text("""
                    DELETE FROM passos
                    WHERE tarefa_id = :tarefa_id
                """),
                {"tarefa_id": tarefa_id}
            )

            for ordem, texto_passo in enumerate(
                passos,
                start=1
            ):
                session.execute(
                    text("""
                        INSERT INTO passos (
                            tarefa_id,
                            texto,
                            concluido,
                            ordem
                        )
                        VALUES (
                            :tarefa_id,
                            :texto,
                            FALSE,
                            :ordem
                        )
                    """),
                    {
                        "tarefa_id": tarefa_id,
                        "texto": texto_passo,
                        "ordem": ordem
                    }
                )

            session.commit()

        return self.listar_passos(tarefa_id)

    def criar(
        self,
        usuario_id,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None,
        concluida=False
    ):
        with SessionLocal() as session:
            tarefa = Tarefa(
                usuario_id=usuario_id,
                tipo=tipo,
                titulo=titulo,
                descricao=descricao,
                prioridade=prioridade,
                prazo=prazo,
                concluida=concluida
            )

            session.add(tarefa)
            session.commit()
            session.refresh(tarefa)

            return tarefa

    def atualizar_status(
        self,
        tarefa_id,
        concluida
    ):
        with SessionLocal() as session:
            tarefa = session.get(Tarefa, tarefa_id)

            if tarefa is None:
                return None

            tarefa.concluida = concluida
            session.commit()
            session.refresh(tarefa)

            return tarefa

    def excluir(self, tarefa_id):
        with SessionLocal() as session:
            tarefa = session.get(Tarefa, tarefa_id)

            if tarefa is None:
                return False

            session.delete(tarefa)
            session.commit()

            return True
