﻿from datetime import date, datetime

from repositories.tarefa_repository import TarefaRepository
from core.ia_service import gerar_passos_tarefa


class TarefaService:
    TIPOS_VALIDOS = [
        "tarefas_diarias",
        "tarefas_educacionais"
    ]

    PRIORIDADES_VALIDAS = [
        "baixa",
        "media",
        "alta"
    ]

    def __init__(self, repository=None):
        self.repository = repository or TarefaRepository()

    def listar_tarefas(
        self,
        usuario_id=None,
        tipo=None
    ):
        if tipo is not None:
            self._validar_tipo(tipo)

        if usuario_id is None:
            return self.repository.listar()

        return self.repository.listar_por_usuario(
            usuario_id,
            tipo
        )

    def buscar_tarefa(self, tarefa_id):
        tarefa = self.repository.buscar_por_id(
            tarefa_id
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        return tarefa

    def buscar_tarefa_autorizado(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        tarefa = self.buscar_tarefa(
            tarefa_id
        )

        if (
            tarefa.usuario_id != usuario_autenticado.id
            and usuario_autenticado.papel != "admin"
        ):
            raise PermissionError(
                "Você não tem permissão para consultar esta tarefa."
            )

        return tarefa

    
    def listar_tarefas_autorizado(
        self,
        usuario_autenticado,
        usuario_id=None
    ):
        if usuario_autenticado.papel == "admin":
            return self.listar_tarefas(
                usuario_id=usuario_id
            )

        if (
            usuario_id is not None
            and usuario_id != usuario_autenticado.id
        ):
            raise PermissionError(
                "Você não tem permissão para consultar as tarefas deste usuário."
            )

        return self.listar_tarefas(
            usuario_id=usuario_autenticado.id
        )
    
    def listar_passos(self, tarefa_id):
        tarefa = self.repository.buscar_por_id(
            tarefa_id
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        return self.repository.listar_passos(
            tarefa_id
        )

    def gerar_passos(self, tarefa_id):
        tarefa = self.repository.buscar_por_id(
            tarefa_id
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        passos = gerar_passos_tarefa(
            tarefa.titulo
        )

        if not passos:
            raise ValueError(
                "A IA não gerou passos para a tarefa."
            )

        if passos[0].startswith("Erro:"):
            raise ValueError(
                passos[0]
            )

        if passos[0].startswith(
            "Configure a GEMINI_API_KEY"
        ):
            raise ValueError(
                passos[0]
            )

        if passos[0].startswith(
            "Não foi possível gerar os passos"
        ):
            raise ValueError(
                passos[0]
            )

        return self.repository.salvar_passos(
            tarefa_id,
            passos
        )

    def criar_tarefa(
        self,
        usuario_id,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None
    ):
        titulo = titulo.strip()

        if not titulo:
            raise ValueError(
                "O título da tarefa é obrigatório."
            )

        if len(titulo) < 3:
            raise ValueError(
                "O título deve ter pelo menos 3 caracteres."
            )

        self._validar_tipo(tipo)
        self._validar_prioridade(prioridade)

        prazo_formatado = self._formatar_prazo(prazo)

        return self.repository.criar(
            usuario_id=usuario_id,
            tipo=tipo,
            titulo=titulo,
            descricao=descricao,
            prioridade=prioridade,
            prazo=prazo_formatado,
            concluida=False
        )

    def atualizar_status(
        self,
        tarefa_id,
        concluida
    ):
        tarefa = self.repository.atualizar_status(
            tarefa_id,
            concluida
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        return tarefa

    def atualizar_status_passo(
        self,
        tarefa_id,
        passo_id,
        concluido
    ):
        tarefa = self.repository.buscar_por_id(
            tarefa_id
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        passo = self.repository.atualizar_status_passo(
            tarefa_id,
            passo_id,
            concluido
        )

        if passo is None:
            raise ValueError(
                "Passo não encontrado para esta tarefa."
            )

        return passo

    def _validar_tipo(self, tipo):
        if tipo not in self.TIPOS_VALIDOS:
            raise ValueError(
                "Tipo de tarefa inválido."
            )

    def _validar_prioridade(self, prioridade):
        if prioridade not in self.PRIORIDADES_VALIDAS:
            raise ValueError(
                "Prioridade inválida."
            )

    def _formatar_prazo(self, prazo):
        if prazo is None or prazo == "":
            return None

        if isinstance(prazo, date):
            return prazo

        if isinstance(prazo, str):
            try:
                return datetime.strptime(
                    prazo,
                    "%Y-%m-%d"
                ).date()

            except ValueError:
                raise ValueError(
                    "Prazo inválido. Use AAAA-MM-DD."
                )

        raise ValueError(
            "Formato de prazo inválido."
        )

    def excluir_tarefa(self, tarefa_id):
        tarefa = self.repository.buscar_por_id(
            tarefa_id
        )

        if tarefa is None:
            raise ValueError(
                "Tarefa não encontrada."
            )

        excluiu = self.repository.excluir(
            tarefa_id
        )

        if not excluiu:
            raise ValueError(
                "Não foi possível excluir a tarefa."
            )

        return True

    def criar_tarefa_autorizado(
        self,
        usuario_autenticado,
        usuario_id,
        tipo,
        titulo,
        descricao=None,
        prioridade="media",
        prazo=None
    ):
        if (
            usuario_autenticado.id != usuario_id
            and usuario_autenticado.papel != "admin"
        ):
            raise PermissionError(
                "Você não tem permissão para criar tarefas para este usuário."
            )

        return self.criar_tarefa(
            usuario_id=usuario_id,
            tipo=tipo,
            titulo=titulo,
            descricao=descricao,
            prioridade=prioridade,
            prazo=prazo
        )


    def atualizar_status_autorizado(
        self,
        usuario_autenticado,
        tarefa_id,
        concluida
    ):
        self.buscar_tarefa_autorizado(
            usuario_autenticado,
            tarefa_id
        )

        return self.atualizar_status(
            tarefa_id,
            concluida
        )


    def listar_passos_autorizado(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        self.buscar_tarefa_autorizado(
            usuario_autenticado,
            tarefa_id
        )

        return self.listar_passos(
            tarefa_id
        )


    def atualizar_status_passo_autorizado(
        self,
        usuario_autenticado,
        tarefa_id,
        passo_id,
        concluido
    ):
        self.buscar_tarefa_autorizado(
            usuario_autenticado,
            tarefa_id
        )

        return self.atualizar_status_passo(
            tarefa_id,
            passo_id,
            concluido
        )


    def gerar_passos_autorizado(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        self.buscar_tarefa_autorizado(
            usuario_autenticado,
            tarefa_id
        )

        return self.gerar_passos(
            tarefa_id
        )


    def excluir_tarefa_autorizado(
        self,
        usuario_autenticado,
        tarefa_id
    ):
        self.buscar_tarefa_autorizado(
            usuario_autenticado,
            tarefa_id
        )

        return self.excluir_tarefa(
            tarefa_id
        )