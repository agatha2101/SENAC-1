from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import os
import secrets

import jwt
from dotenv import load_dotenv

from repositories.usuario_repository import UsuarioRepository


load_dotenv()

class UsuarioService:
    def __init__(self, repository=None):
        self.repository = repository or UsuarioRepository()

    def listar_usuarios(self):
        return self.repository.listar()

    def buscar_usuario(self, usuario_id):
        usuario = self.repository.buscar_por_id(
            usuario_id
        )

        if usuario is None:
            raise ValueError(
                "Usuário não encontrado."
            )

        return usuario

    def buscar_usuario_autorizado(
        self,
        usuario_autenticado,
        usuario_id
    ):
        if (
            usuario_autenticado.id != usuario_id
            and usuario_autenticado.papel != "admin"
        ):
            raise PermissionError(
                "Você não tem permissão para consultar este usuário."
            )

        return self.buscar_usuario(
            usuario_id
        )

    def listar_usuarios_autorizado(
        self,
        usuario_autenticado
    ):
        if usuario_autenticado.papel != "admin":
            raise PermissionError(
                "Você não tem permissão para listar usuários."
            )

        return self.listar_usuarios()

    def atualizar_usuario(
        self,
        usuario_id,
        nome,
        estilo_instrucao,
        senha=None
    ):
        usuario = self.repository.buscar_por_id(
            usuario_id
        )

        if usuario is None:
            raise LookupError(
                "Usuário não encontrado."
            )

        nome = nome.strip()

        if not nome:
            raise ValueError(
                "O nome não pode ficar vazio."
            )

        if len(nome) < 3:
            raise ValueError(
                "O nome precisa ter pelo menos 3 caracteres."
            )

        if estilo_instrucao not in {
            "direto",
            "detalhado"
        }:
            raise ValueError(
                "O estilo deve ser 'direto' ou 'detalhado'."
            )

        existente = self.repository.buscar_por_nome(
            nome
        )

        if (
            existente is not None
            and existente.id != usuario_id
        ):
            raise ValueError(
                "Já existe um perfil com esse nome."
            )

        senha_hash = None

        if senha is not None:
            if not senha:
                raise ValueError(
                    "A senha não pode ficar vazia."
                )

            senha_hash = self._gerar_hash_senha(
                senha
            )

        usuario = self.repository.atualizar(
            usuario_id,
            nome,
            estilo_instrucao,
            senha_hash
        )

        return usuario

    def criar_usuario(
            self,
            nome,
            senha,
            estilo_instrucao
        ):
            nome = nome.strip()

            if not nome:
                raise ValueError("O nome não pode ficar vazio.")

            if len(nome) < 3:
                raise ValueError(
                    "O nome precisa ter pelo menos 3 caracteres."
                )

            if not senha:
                raise ValueError(
                    "A senha não pode ficar vazia."
                )

            if estilo_instrucao not in {
                "direto",
                "detalhado"
            }:
                raise ValueError(
                    "O estilo deve ser 'direto' ou 'detalhado'."
                )

            existente = self.repository.buscar_por_nome(nome)

            if existente is not None:
                raise ValueError(
                    "Já existe um perfil com esse nome."
                )

            senha_hash = self._gerar_hash_senha(
                senha
            )

            return self.repository.criar(
                nome,
                senha_hash,
                estilo_instrucao
            )

    def excluir_usuario(self, usuario_id):
        usuario = self.repository.buscar_por_id(
            usuario_id
        )

        if usuario is None:
            raise LookupError(
                "Usuário não encontrado."
            )

        excluiu = self.repository.excluir(
            usuario_id
        )

        if not excluiu:
            raise LookupError(
                "Usuário não encontrado."
            )

        return True

    def excluir_usuario_autorizado(
        self,
        usuario_autenticado,
        usuario_id
    ):
        if usuario_autenticado.papel != "admin":
            raise PermissionError(
                "Você não tem permissão para excluir usuários."
            )

        return self.excluir_usuario(
            usuario_id
        )
    
    def _verificar_senha(
        self,
        senha,
        senha_hash
    ):
        try:
            algoritmo, iteracoes, salt, hash_salvo = (
                senha_hash.split("$")
            )

            if algoritmo != "pbkdf2_sha256":
                return False

            hash_calculado = hashlib.pbkdf2_hmac(
                "sha256",
                senha.encode("utf-8"),
                bytes.fromhex(salt),
                int(iteracoes)
            ).hex()

            return hmac.compare_digest(
                hash_calculado,
                hash_salvo
            )

        except (ValueError, AttributeError):
            return False


    def autenticar(self, nome, senha):
        nome = nome.strip()

        if not nome or not senha:
            raise PermissionError(
                "Usuário ou senha inválidos."
            )

        usuario = self.repository.buscar_por_nome(
            nome
        )

        if (
            usuario is None
            or not usuario.senha_hash
        ):
            raise PermissionError(
                "Usuário ou senha inválidos."
            )

        if not self._verificar_senha(
            senha,
            usuario.senha_hash
        ):
            raise PermissionError(
                "Usuário ou senha inválidos."
            )

        return usuario

    def _gerar_hash_senha(self, senha):
        salt = secrets.token_bytes(16)
        iteracoes = 310000

        hash_senha = hashlib.pbkdf2_hmac(
            "sha256",
            senha.encode("utf-8"),
            salt,
            iteracoes
        ).hex()

        return (
            f"pbkdf2_sha256$"
            f"{iteracoes}$"
            f"{salt.hex()}$"
            f"{hash_senha}"
        )

    def gerar_token_acesso(self, usuario):
        segredo = os.getenv("JWT_SECRET_KEY")

        if not segredo:
            raise RuntimeError(
                "JWT_SECRET_KEY não configurada."
            )

        minutos = int(
            os.getenv(
                "JWT_EXPIRE_MINUTES",
                "60"
            )
        )

        agora = datetime.now(
            timezone.utc
        )

        payload = {
            "sub": str(usuario.id),
            "iat": agora,
            "exp": agora + timedelta(
                minutes=minutos
            )
        }

        return jwt.encode(
            payload,
            segredo,
            algorithm="HS256"
        )

    def validar_token_acesso(self, authorization):
        if not authorization:
            raise PermissionError(
                "Token de acesso não informado."
            )

        if not authorization.startswith("Bearer "):
            raise PermissionError(
                "Token de acesso inválido."
            )

        token = authorization.removeprefix(
            "Bearer "
        ).strip()

        if not token:
            raise PermissionError(
                "Token de acesso inválido."
            )

        segredo = os.getenv("JWT_SECRET_KEY")

        if not segredo:
            raise RuntimeError(
                "JWT_SECRET_KEY não configurada."
            )

        try:
            payload = jwt.decode(
                token,
                segredo,
                algorithms=["HS256"]
            )

            usuario_id = int(
                payload["sub"]
            )

        except jwt.ExpiredSignatureError:
            raise PermissionError(
                "Token expirado."
            )

        except (
            jwt.InvalidTokenError,
            KeyError,
            ValueError
        ):
            raise PermissionError(
                "Token de acesso inválido."
            )

        usuario = self.repository.buscar_por_id(
            usuario_id
        )

        if usuario is None:
            raise PermissionError(
                "Usuário autenticado não encontrado."
            )

        return usuario

    def atualizar_usuario_autorizado(
        self,
        usuario_autenticado,
        usuario_id,
        nome,
        estilo_instrucao,
        senha=None
    ):
        if (
            usuario_autenticado.id != usuario_id
            and usuario_autenticado.papel != "admin"
        ):
            raise PermissionError(
                "Você não tem permissão para atualizar este usuário."
            )

        return self.atualizar_usuario(
            usuario_id,
            nome,
            estilo_instrucao,
            senha
        )