from core.ia_service import obter_resposta_ia
from repositories.usuario_repository import UsuarioRepository


class IaService:
    def __init__(self, usuario_repository=None):
        self.usuario_repository = (
            usuario_repository or UsuarioRepository()
        )

    def perguntar(
        self,
        usuario_id,
        pergunta
    ):
        pergunta = pergunta.strip()

        if not pergunta:
            raise ValueError(
                "A pergunta não pode ficar vazia."
            )

        usuario = self.usuario_repository.buscar_por_id(
            usuario_id
        )

        if usuario is None:
            raise ValueError(
                "Usuário não encontrado."
            )

        resposta = obter_resposta_ia(
            pergunta,
            usuario.estilo_instrucao
        )

        if not resposta:
            raise ValueError(
                "A IA não retornou uma resposta."
            )

        if resposta[0].startswith("Erro"):
            raise ValueError(
                resposta[0]
            )

        return resposta